

<!-- white-box -->
            <div class="col-lg-10 col-md-12">
                <div class="chat-bg">
                    <div class="light-grey-bg">
                        <div class="container">
                            <div class="row top-heading ">
                                <div class="m-card-set">
                                    <svg class="m-card" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M31.744 27.332a1 1 0 0 1-.076 1.412c-.11.099-2.732 2.411-6.64 2.411-3.909 0-6.53-2.312-6.64-2.411a1 1 0 0 1 1.333-1.491c.033.03 2.195 1.902 5.306 1.902 3.152 0 5.284-1.88 5.305-1.899a.998.998 0 0 1 1.412.076zM25 48C12.318 48 2 37.682 2 25S12.318 2 25 2s23 10.318 23 23-10.318 23-23 23zm0-48C11.193 0 0 11.193 0 25s11.193 25 25 25 25-11.193 25-25S38.807 0 25 0zm10 38.697a.853.853 0 0 1-.06.268l-7-3.73L27.5 35H16c-.552 0-1-.449-1-1V16c0-.551.448-1 1-1h18c.551 0 1 .449 1 1v22.697zM34 13H16c-1.654 0-3 1.346-3 3v18c0 1.654 1.346 3 3 3h11l7.028 3.746h.001A2 2 0 0 0 35 41c.35 0 .698-.093 1.014-.279.617-.363.986-1.308.986-2.024V16c0-1.654-1.346-3-3-3z"></path>
                                    </svg>
                                </div>
                                <div class="col-lg-3 col-md-4">
                                    <h1>Academic</h1>
                                </div>
                                <div class="col-lg-4 col-md-4  pl-4 border-left">
                                    <p>Use your academic personal website to highlight your personality, profile, research findings, affiliations and more.</p>
                                </div>
                                <div class="col-lg-4 col-md-2">
                                 <div class="home-online-user-icon">
                                  <a href="javascript:void(0);"><i class="la la-expand"></i></i></a>
                                 <a class="dropdown-toggle" data-toggle="dropdown"><i class="la la-ellipsis-v"></i></a>
                                 <div class="dropdown-menu">
                                    <a class="dropdown-item" href="#">Link 1</a>
                                    <a class="dropdown-item" href="#">Link 2</a>
                                    <a class="dropdown-item" href="#">Link 3</a>     
                                 </div>
                              </div>
                          </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-lg-7 col-xl-7">
                <div class="container">
                    <div class="row pt-4">
                        <div class="col-md-12">
                            <h2><span style="color: #88888b;">Academic </span></h2>
                        </div>
                    </div>
                    <div class="row pt-4">
                        <div class="col-md-12">
                            <div id="accordion">
                                <div class="card">
                                    <div class="card-header" id="headingOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        <div class="row pt-2 pb-2 ">
                                            <div class="col-md-1">
                                                <i class="la la-size la-mobile-phone"></i>
                                            </div>
                                            <div class="col-md-9">
                                                <h5 class="mb-0">What is Lorem Ipsum?</h5>
                                                <p>Lorem Ipsum is simply dummy text</p>
                                            </div>
                                            <div class="col-md-2 text-center">
                                                <button class="btn btn-link rotate" >
                                                    <i class="la la-angle-right mobile-hide"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-1">
                                                </div>
                                                <div class="col-md-9">
                                                    <p>Why do we use it?</p>



                                                    <p>  It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).    </p>


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="pt-2">
                                    <div class="card">
                                        <div class="card-header" id="heading2" data-toggle="collapse" data-target="#collapse2" aria-expanded="true" aria-controls="collapse2">
                                            <div class="row pt-2 pb-2 ">
                                                <div class="col-md-1">
                                                    <i class="la la-size la-pencil-square"></i>
                                                </div>
                                                <div class="col-md-9">
                                                    <h5 class="mb-0">What is Lorem Ipsum?</h5>
                                                    <p>Lorem Ipsum is simply dummy text</p>
                                                </div>
                                                <div class="col-md-2 text-center">
                                                    <button class="btn btn-link rotate" >
                                                        <i class="la la-angle-right mobile-hide"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="collapse2" class="collapse" aria-labelledby="heading2" data-parent="#accordion">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-1">
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p>Why do we use it?</p>



                                                        <p>  It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).    </p>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="pt-2">
                                    <div class="card">
                                        <div class="card-header" id="heading3" data-toggle="collapse" data-target="#collapse3" aria-expanded="true" aria-controls="collapse3">
                                            <div class="row pt-2 pb-2 ">
                                                <div class="col-md-1">
                                                    <i class="la la-size la-camera-retro"></i>
                                                </div>
                                                <div class="col-md-9">
                                                    <h5 class="mb-0">What is Lorem Ipsum?</h5>
                                                    <p>Lorem Ipsum is simply dummy text</p>
                                                </div>
                                                <div class="col-md-2 text-center">
                                                    <button class="btn btn-link rotate" >
                                                        <i class="la la-angle-right mobile-hide"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="collapse3" class="collapse" aria-labelledby="heading3" data-parent="#accordion">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-1">
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p>Why do we use it?</p>



                                                        <p>  It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).    </p>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="pt-2">
                                    <div class="card">
                                        <div class="card-header" id="heading4" data-toggle="collapse" data-target="#collapse4" aria-expanded="true" aria-controls="collapse4">
                                            <div class="row pt-2 pb-2 ">
                                                <div class="col-md-1">
                                                    <i class="la la-size la-laptop"></i>
                                                </div>
                                                <div class="col-md-9">
                                                    <h5 class="mb-0">What is Lorem Ipsum?</h5>
                                                    <p>Lorem Ipsum is simply dummy text</p>
                                                </div>
                                                <div class="col-md-2 text-center">
                                                    <button class="btn btn-link rotate" >
                                                        <i class="la la-angle-right mobile-hide"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="collapse4" class="collapse" aria-labelledby="heading4" data-parent="#accordion">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-1">
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p>Why do we use it?</p>



                                                        <p>  It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).    </p>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="pt-2">
                                    <div class="card">
                                        <div class="card-header" id="heading5" data-toggle="collapse" data-target="#collapse5" aria-expanded="true" aria-controls="collapse5">
                                            <div class="row pt-2 pb-2 ">
                                                <div class="col-md-1">
                                                    <i class="la la-size la-calendar-check-o"></i>
                                                </div>
                                                <div class="col-md-9">
                                                    <h5 class="mb-0">What is Lorem Ipsum?</h5>
                                                    <p>Lorem Ipsum is simply dummy text</p>
                                                </div>
                                                <div class="col-md-2 text-center">
                                                    <button class="btn btn-link rotate" >
                                                        <i class="la la-angle-right mobile-hide"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="collapse5" class="collapse" aria-labelledby="heading5" data-parent="#accordion">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-1">
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p>Why do we use it?</p>



                                                        <p>  It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).    </p>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
                        <div class=" col-lg-4 col-md-12 pt-8">
                            <div class="academic-form">
                            <form>
                                <h2 class="pb-4">Academic Form</h2>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="username" placeholder="Username" required="required">
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" name="email" placeholder="Email Address" required="required">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="password" placeholder="Password" required="required">
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="confirm_password" placeholder="Confirm Password" required="required">
                                </div>
                                <div class="form-group">
                                    <label class="checkbox-inline"><input type="checkbox" required="required"> I accept the <a href="#">Terms of Use</a> &amp; <a href="#">Privacy Policy</a></label>
                                </div>
                               <div class="form-group">
                                    <button type="submit" class="btn my-btn btn-primary btn-sm">Get Started</button>
                                </div>
                            </form>

                        </div>





                        </div>
                    </div>
                </div>
            </div>
        </div>
