<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title>Cbl</title>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700|Poppins:300,400,500,600" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/vendor.bundle.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/app.bundle.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/theme-a.css">
	
	<link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/bootstrap-multiselect.css">
	<script src="<?php echo base_url();?>assets/admin/plugins/ckeditor/ckeditor.js"></script>

	<script src="<?php echo base_url();?>assets/admin/js/jquery-2.1.1.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/admin/js/common.js"></script> 
	<script type="text/javascript">
		var base_url = '<?php echo base_url();?>';
	</script>
	<link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/bootstrap-datetimepicker.min.css">
	<script src="<?php echo base_url();?>assets/admin/js/bootstrap-datetimepicker.min.js"></script>
</head>
<body>
  <div id="app_wrapper">
	<header id="app_topnavbar-wrapper">
	  <nav role="navigation" class="navbar topnavbar">
		<div class="nav-wrapper">
		  <div id="logo_wrapper" class="nav navbar-nav">
			<ul>
			  <li class="logo-icon">
			    <a href="<?php echo base_url();?>admin">
				  <div class="logo">&nbsp;&nbsp;&nbsp;Cbl
					<!-- <img src="<?php echo base_url();?>assets/site/images/logo.png"> -->
				  </div>				  
				</a>
			  </li>
			</ul>
		  </div>
		  <ul class="nav navbar-nav left-menu ">
			<li class="menu-icon">
			  <a href="javascript:void(0)" role="button" data-toggle-state="app_sidebar-menu-collapsed" data-key="leftSideBar">
				<i class="mdi mdi-backburger"></i>
			  </a>
		    </li>
		  </ul>
		  <ul class="nav navbar-nav pull-right">
			<li class="last">
			  <a href="<?php echo base_url();?>admin/logout" data-toggle-state="sidebar-overlay-open" data-key="rightSideBar">
				<i class="zmdi zmdi-power zmdi-hc-fw"></i>
				<div class="ripple-container"></div></a>
			</li>
		  </ul>
		</div>
		<form role="search" action="" class="navbar-form" id="navbar_form">
		  <div class="form-group is-empty">
			<input type="text" placeholder="Search and press enter..." class="form-control" id="navbar_search" autocomplete="off">
			  <i data-navsearch-close="" class="zmdi zmdi-close close-search"></i>
		  </div>
		  <button type="submit" class="hidden btn btn-default">Submit</button>
		</form>
	  </nav>
	</header>
	 <aside id="app_sidebar-left">
	   <nav id="app_main-menu-wrapper" class="scrollbar">
		 <div class="sidebar-inner sidebar-push">
		  <ul class="nav nav-pills nav-stacked">
			<li class="sidebar-header">NAVIGATION</li>
			<li class="<?php if($this->uri->segment(2)==''){?>active<?php } ?>"><a href="<?php echo base_url();?>admin"><i class="zmdi zmdi-home"></i>Dashboard</a></li>
			
			<li class="<?php if($this->uri->segment(2)=='profile'){?>active<?php } ?>"><a href="<?php echo base_url();?>admin/profile"><i class="zmdi zmdi-account-o"></i>Profile</a></li>
			<li <?php if($this->uri->segment(3)=='about' || $this->uri->segment(2)=='addTerm' || $this->uri->segment(2)=='addQuestion' || $this->uri->segment(3)=='privacy' || $this->uri->segment(2)=='terms' ||  $this->uri->segment(2)=='howitwork'){ ?>class="active open"<?php } ?>><a href><span></span><i class="zmdi zmdi-edit"></i>CMS</a>
		  	  <ul class="nav-sub" data-index="0" style="display: none;">
			    <li class="<?php if($this->uri->segment(3)=='about'){?>active<?php } ?>"><a href="<?php echo base_url();?>admin/cms/about">About</a></li>
                 <li class="<?php if($this->uri->segment(3)=='terms'){?>active<?php } ?>"><a href="<?php echo base_url();?>admin/cms/terms">Terms & condition</a></li>
				<li class="<?php if($this->uri->segment(3)=='privacy'){?>active<?php } ?>"><a href="<?php echo base_url();?>admin/cms/privacy">Privacy Policy</a></li>
		      </ul>
			</li>
			<li class="<?php if($this->uri->segment(2)=='player' || $this->uri->segment(2)=='viewReview' || $this->uri->segment(2)=='player'){?>active<?php } ?>"><a href="<?php echo base_url();?>admin/user/player"><i class="zmdi zmdi-accounts"></i> Player </a></li>

			<li class="<?php if($this->uri->segment(2)=='coach' || $this->uri->segment(2)=='viewReview' || $this->uri->segment(2)=='viewcoach'){?>active<?php } ?>"><a href="<?php echo base_url();?>admin/user/coach"><i class="zmdi zmdi-accounts"></i> View Coach </a></li>

			<li class="<?php if($this->uri->segment(2)=='player' || $this->uri->segment(2)=='player' || $this->uri->segment(2)=='teamowner'){?>active<?php } ?>"><a href="<?php echo base_url();?>admin/user/teamowner"><i class="zmdi zmdi-accounts"></i> Team Owner </a></li>

			<li class="<?php if($this->uri->segment(2)=='coach' || $this->uri->segment(2)=='fibaagent' || $this->uri->segment(2)=='fibaagent'){?>active<?php } ?>"><a href="<?php echo base_url();?>admin/user/agent"><i class="zmdi zmdi-accounts"></i> NBA/FIBA Agent </a></li>

			<li class="<?php if($this->uri->segment(2)=='gameofficial' || $this->uri->segment(2)=='gameofficial' || $this->uri->segment(2)=='gameofficial'){?>active<?php } ?>"><a href="<?php echo base_url();?>admin/user/gameofficial"><i class="zmdi zmdi-accounts"></i> Game official </a></li>

			<li class="<?php if($this->uri->segment(2)=='fan' || $this->uri->segment(2)=='fan' || $this->uri->segment(2)=='fan'){?>active<?php } ?>"><a href="<?php echo base_url();?>admin/user/fan"><i class="zmdi zmdi-accounts"></i> Fan</a></li>
			
			
			<li class="<?php if($this->uri->segment(2)=='usercontact'){?>active<?php } ?>"><a href="<?php echo base_url();?>admin/usercontact"><i class="zmdi zmdi-email"></i>Contact Us</a></li>

			<li class="<?php if($this->uri->segment(2)=='newas'){?>active<?php } ?>"><a href="<?php echo base_url();?>admin/news"><i class="zmdi zmdi-email"></i>News</a></li>	

			<li class="<?php if($this->uri->segment(2)=='league'){?>active<?php } ?>"><a href="<?php echo base_url();?>admin/league"><i class="zmdi zmdi-accounts"></i>league</a></li>
            
            <li class="<?php if($this->uri->segment(2)=='membership'){?>active<?php } ?>"><a href="<?php echo base_url();?>admin/membership"><i class="zmdi zmdi-accounts"></i>Membership Plan</a></li>

		  </ul>
		</div>
	  </nav>
	</aside>	
  <section id="content_outer_wrapper">