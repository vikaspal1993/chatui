
<!-- whitebox - start-->
<div class="col-md-12 col-lg-10">
    <div class="chat-bg">
        <div class="w-100">
            <div class="light-grey-bg">
                <div class="container">
                    <div class="row top-heading ">
                        <div class="m-card-set">
                            <svg class="m-card" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><path d="M9 40a4 4 0 0 1-4-4h2a2 2 0 0 0 2 2h27a2 2 0 0 0 2-2V15a2 2 0 0 0-2-2v-2a4 4 0 0 1 4 4v21a4 4 0 0 1-4 4H9z"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M25.861 6L18.5 0l-7.361 6H4a4 4 0 0 0-4 4v22a4 4 0 0 0 4 4h28a4 4 0 0 0 4-4V10a4 4 0 0 0-4-4h-6.139zM18.5 2.58L11.85 8H4a2 2 0 0 0-2 2v22a2 2 0 0 0 2 2h28a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2h-6.85L18.5 2.58z"></path><path d="M5 12h23v2H5zm0 4h26v2H5zm0 4h14v2H5z"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M22.5 29a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1zm0 1a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm-4-1a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1zm0 1a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"></path><path d="M16 28.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"></path></svg>
                        </div>
                        <div class="col-lg-3 col-md-4">
                            <h1>Roadmap </h1>
                        </div>
                        <div class="col-lg-4 col-md-4  pl-4 border-left">
                             <p>The main purpose of a product roadmap is to tie a product's vision in with a company's business objectives. </p>
                        </div>
                           <div class="col-lg-4 col-md-2">
                                    <div class="home-online-user-icon">
                                  <a href="javascript:void(0);"><i class="la la-expand"></i></i></a>
                                 <a class="dropdown-toggle" data-toggle="dropdown"><i class="la la-ellipsis-v"></i></a>
                                 <div class="dropdown-menu">
                                    <a class="dropdown-item" href="#">Link 1</a>
                                    <a class="dropdown-item" href="#">Link 2</a>
                                    <a class="dropdown-item" href="#">Link 3</a>     
                                 </div>
                              </div>
                          </div>
                    </div>
                </div>
            </div>

<div class="row">
<div class="col-md-8">
<div class="user-table-main px-4">

                <div class="table-head  ">
                    <table class="table table-responsive border table-striped">
                        <thead>
                        <tr class="head-row">
                            <th>Title</th>
                            <th>Author</th>
                            <th>Where it is</th>
                            <th>Time</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr class="tabel-body-row">
                            <td>Untitled</td>
                            <td>John doe</td>
                            <td> ___ </td>
                            <td>60 <small>Min</small></td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit"></i></span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i> </span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Untitled</td>
                            <td>John doe</td>
                            <td> ___ </td>
                            <td>60 <small>Min</small></td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit"></i></span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i> </span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Untitled</td>
                            <td>John doe</td>
                            <td> ___ </td>
                            <td>60 <small>Min</small></td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit"></i></span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i> </span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Untitled</td>
                            <td>John doe</td>
                            <td> Started </td>
                            <td>60 <small>Min</small></td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit"></i></span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i> </span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Untitled</td>
                            <td>John doe</td>
                            <td> ___ </td>
                            <td>60 <small>Min</small></td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit"></i></span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i> </span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Untitled</td>
                            <td>John doe</td>
                            <td> ___ </td>
                            <td>60 <small>Min</small></td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit"></i></span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i> </span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Untitled</td>
                            <td>John doe</td>
                            <td> ___ </td>
                            <td>60 <small>Min</small></td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit"></i></span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i> </span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Untitled</td>
                            <td>John doe</td>
                            <td> ___ </td>
                            <td>60 <small>Min</small></td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit"></i></span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i> </span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Untitled</td>
                            <td>John doe</td>
                            <td> ___ </td>
                            <td>60 <small>Min</small></td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit"></i></span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i> </span></a>
                            </td>
                        </tr>
                        <tr>

                        </tr>
                        </tbody>

                    </table>
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-end">
                            <li class="page-item disabled">
                                <a class="page-link" href="#" tabindex="-1">Previous</a>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>

            </div>
</div>
<div class="col-md-4 pt-35">
<div class="knowledege-form">
                            <form>
                                <h2 class="pb-4">Roadmap Form</h2>
                                <div class="form-group">
                                    <input class="form-control" name="username" placeholder="Username" required="required" type="text">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="email" placeholder="Email Address" required="required" type="email">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="password" placeholder="Password" required="required" type="text">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="confirm_password" placeholder="Confirm Password" required="required" type="password">
                                </div>
                                <div class="form-group">
                                    <label class="checkbox-inline"><input required="required" type="checkbox"> I accept the <a href="#">Terms of Use</a> &amp; <a href="#">Privacy Policy</a></label>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-sm">Get Started</button>
                                </div>
                            </form>

                        </div>
</div>
</div>




            
        </div>
    </div>
    <!-- whitebox - end-->

