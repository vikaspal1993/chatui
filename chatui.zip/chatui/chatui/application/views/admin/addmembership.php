<div id="content_wrapper">
  <div id="header_wrapper" class="header-sm">
    <div class="container-fluid">
      <div class="row">
        <div class="col-xs-12">
          <header id="header">
            <h1>Add Membership</h1>
          </header>
        </div>
      </div>
    </div>
  </div>
  <div id="content" class="container-fluid">
    <div class="content-body">
    <div class="row">
      <div class="col-xs-12 col-sm-12">
        <?php if($this->session->flashdata('success')) : ?>
            <div class="alert alert-success" role="alert">
              <?php echo $this->session->flashdata('success');?>
            </div>
            <?php endif; ?>
            <?php if($this->session->flashdata('errormsg')) : ?>
            <div class="alert alert-danger" role="alert">
              <strong>Error!</strong> Change a few things up and try submitting again...but not.
            </div>
            <?php endif; ?>
        <div class="card p-b-20">
          <header class="card-heading ">
            <ul class="card-actions icons right-top">
              <li>
              </li>
            </ul>
          </header>
          <div class="card-body">
            
            <form class="form-horizontal" method="post" enctype="multipart/form-data">
              
              <div class="form-group is-empty">
                <label for="name" class="col-md-2 control-label">Plan name</label>
                <div class="col-md-10">
                  <input type="text" class="form-control" name="planname" placeholder="planname Title" id="planname"/>
                </div>
              </div>

               <div class="form-group is-empty">
                <label for="name" class="col-md-2 control-label">Plan price</label>
                <div class="col-md-10">
                  <input type="text" class="form-control" name="planprice" placeholder="planprice Title" id="planprice"/>
                </div>
              </div>
              <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Description</label>
                  <div class="col-sm-10">       
                     <textarea class="ckeditor" id="description" name="description"></textarea>
                  </div>
              </div>          
              <div class="form-group is-empty">
                <div class="col-sm-10 col-sm-offset-2">
                  <input type="submit" class="btn btn-info" value="submit">
                  <a class="btn btn-default" href="<?php echo base_url();?>admin/addmembership" value="Back" >BACK</a>
                </div>
              </div>
            </form>
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>