

<!doctype html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link href="https://fonts.googleapis.com/css?family=Fira+Sans:400,500,600&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="assets/css/bootstrap.min.css">
      <link rel="stylesheet" href="assets/css/line-awesome.min.css">
      <link rel="stylesheet" href="assets/css/main.css">
      <link rel="stylesheet" href="assets/css/responsive.css">
      <title>Forgot Password</title> 
   </head>
   <body>
      <div class="login-bg">
         <div class="Login-main">
            <div class="col-lg-7 col-md-10 mx-auto">
               <div class="row">
                  <div class="col-lg-6 col-sm-6  login-left">
                     <div class="circle-image">
                        <img src="assets/images/circle.png">
                     </div>
                     <div class="welcom-login">
                        <h6>
                           Welcome to Website Name
                        </h6>
                        <span></span>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                        <button type="button" class="btn btn-outline-light">Know More</button>
                     </div>
                  </div>
                  <div class="col-lg-6 col-sm-6 login-right">
                     <div class="sequre-image">
                        <img src="assets/images/sequre.png">
                     </div>
                     <div class="login-form">
                        <div class="login-text">
                           <h6>
                              Forgot Password?
                           </h6>
                           <span></span>
                           <p class="font-11">Enter either the email address or username on the account. Select Submit. Check your inbox for a password reset email. Click on the URL provided in the email and enter a new password.</p>
                        </div>
                        <form>
                           <div class="input-group mb-3">
                              <div class="input-group-prepend">
                                 <span class="input-group-text login-input-icon" id="basic-addon1"><i class="la la-envelope"></i></span>
                              </div>
                              <input type="text" class="form-control login-input" placeholder="Email Address" aria-label="Email" aria-describedby="basic-addon1">
                           </div>
                           <div class="signin-btn">
                              <button type="button" class="btn sign-btn btn-outline-primary">Send</button>
                           </div>
                        </form>

                        <div class="Login-footer">
                           <a class="login-link" href="register.php">Register</a>
                           <a class="login-link" href="login.php">Login</a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <script src="assets/js/jquery-3.2.1.min.js"></script>
      <script src="assets/js/popper.min.js"></script>
      <script src="assets/js/bootstrap.min.js"></script>
   </body>
</html>

