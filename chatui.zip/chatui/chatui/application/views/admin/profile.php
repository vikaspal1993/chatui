<div id="content_wrapper">
  <div id="header_wrapper" class="header-sm">
    <div class="container-fluid">
      <div class="row">
        <div class="col-xs-12">
          <header id="header">
            <h1>Profile</h1>
          </header>
        </div>
      </div>
    </div>
  </div>
  <div id="content" class="container-fluid">
    <div class="content-body">
    <div class="row">
      <div class="col-xs-12 col-sm-12">
        <div class="card p-b-20">
          <header class="card-heading ">
            <ul class="card-actions icons right-top">
              <li>
              </li>
            </ul>
          </header>
          <div class="card-body">
            <?php if($this->session->flashdata('sucessmsg')) : ?>
            <div class="alert alert-success" role="alert">
              <?php echo $this->session->flashdata('sucessmsg');?>
            </div>
            <?php endif; ?>
            <?php if($this->session->flashdata('errormsg')) : ?>
            <div class="alert alert-danger" role="alert">
              <strong>Error!</strong> Change a few things up and try submitting again...but not.
            </div>
            <?php endif; ?>
            <form class="form-horizontal" method="post">
              <div class="form-group is-empty">
                <label for="name" class="col-md-2 control-label">Name</label>
                <div class="col-md-10">
                  <input type="text" class="form-control" name="name" placeholder="Name"id="name" value="<?php echo $row->name; ?>" required/>
                </div>
              </div>
              <div class="form-group is-empty">
                <label for="inputEmail" class="col-md-2 control-label">Email</label>
                <div class="col-md-10">
                  <input type="text" class="form-control" name="email" placeholder="Email" id="email" value="<?php echo $row->email; ?>" required/>
                </div>
              </div>
              <div class="form-group is-empty">
                <label for="inputPassword" class="col-md-2 control-label">Phone</label>
                <div class="col-md-10">
                  <input type="text" class="form-control" name="phone" placeholder="Phone" id="mobile" onBlur="is_valid(this.value);" value="<?php echo $row->phone; ?>" required maxlength="12" minlength="8" />
                </div>
              </div>  
              <div class="form-group is-empty">
                <label for="textArea" class="col-md-2 control-label">Password</label>
                <div class="col-md-10">
                  <input type="password" class="form-control"  name="password" placeholder="password" id="password" value="<?php echo $row->password; ?>" required/>
                </div>
              </div>
             
              <div class="form-group is-empty">
                <div class="col-sm-10 col-sm-offset-2">
                  <input type="submit" class="btn btn-info" href="<?php echo base_url();?>admin/Profile" value="Upadte">
                </div>
              </div>
               </form>
          </div>
        </div>
        </div>
      </div>
   </div>
 </div>
</div>
</div>

      <script type="text/javascript">
        function is_valid(string_or_number){
          var mobile=string_or_number;
          if(mobile.length<8){
              $('#mobile').addClass("error_border");
              return false;
          }
          if(mobile.length>12){
              $('#mobile').addClass("error_border");
              return false;
          }
          intRegex = /[0-9 -()+]+$/;
          is_mobile=true;
          for ( var i=0; i < mobile.length; i++) {
              if(intRegex.test(mobile[i])){ 
                  continue;
              }else{
                  is_mobile=false;
                  $('#mobile').addClass("error_border");
                  break;
              }
          }
          if(is_mobile){
              $('#mobile').removeClass("error_border");
          }else{
              $('#mobile').val('');
          }
          return is_mobile;
      }
      </script>