<?php
class Admin_model extends CI_Model{

	//select list of data from a table
    public function selectRecord($table,$whr,$limit=false,$orderBy=false,$groupBy=false){
        $this->db->select('*');
        $this->db->from($table);
        if($whr){
            $this->db->where($whr);
        }
        if($limit){
            $this->db->limit($limit);
        }
        if($orderBy){
            $this->db->order_by('id',$orderBy);
        }
        if($groupBy){
            $this->db->group_by($groupBy); 
        }
        $query = $this->db->get();
        return $query->result();
    }

    public function selectRoute($table,$whr,$limit=false,$orderBy=false,$groupBy=false){
        $this->db->select('id,days');
        $this->db->from($table);
        if($whr){
            $this->db->where($whr);
        }
        if($limit){
            $this->db->limit($limit);
        }
        if($orderBy){
            $this->db->order_by('id',$orderBy);
        }
        if($groupBy){
            $this->db->group_by($groupBy); 
        }
        $query = $this->db->get();
        return $query->result();
    }

    //select list of data from a table
    public function selectList($table){
        $this->db->select('*');
        $this->db->from($table);
        $query = $this->db->get();
        return $query->result();
    }

    public function getFlightNumber($id){
        $this->db->select('dp_flight.flight_number');
        $this->db->from('dp_route');
        $this->db->join('dp_flight','dp_route.flight_id=dp_flight.id','left');
        $this->db->where('dp_route.id',$id);
        $query = $this->db->get();
        return $query->row()->flight_number;
    }

    public function getFLightsDataByDestination($destination,$routeDay){
        $route = $this->selectRecord("dp_route",array('destination'=>$destination));
        $final = array();
        foreach($route as $row){
            $whr = array('route_id'=>$row->id,'days'=>$routeDay);
            $row->routes = $this->selectRecord("dp_route_days",$whr,false,false,"days");
            if(count($row->routes)>0){
                array_push($final, $row);
            }
        }
        return $final;
    }
    public function getFLightsData($source,$destination,$routeDay){
    $route = $this->selectRecord("dp_route",array('source'=>$source,'destination'=>$destination));
        $final = array();
        foreach($route as $row){
            $whr = array('route_id'=>$row->id,'days'=>$routeDay);
            $row->routes = $this->selectRecord("dp_route_days",$whr,false,false,"days");
            if(count($row->routes)>0){
                array_push($final, $row);
            }
        }
        return $final;
    }

    public function getRouteData($routeId){
        $days = array('monday','tuesday','wednesday','thursday','friday','saturday','sunday');
        $final = array();
        $i=0;
        foreach ($days as $row) {
            $final[$i]['details'] = $this->selectRecord('dp_route_days',array('route_id'=>$routeId,'days'=>$row));
            $final[$i]['day'] = $row;
            $i++;
        }
        return $final;
    }

    public function getCityCode($city_name){
        $this->db->select("city_code");
        $this->db->from('dp_fly_city');
        $this->db->where('city_name',$city_name);
        $query = $this->db->get();
        return $query->row();
    }

    

    public function selectRow($table,$whr){
        $this->db->select("*");
        $this->db->from($table);
        if($whr){
            $this->db->where($whr);
        }
        $query = $this->db->get();
        return $query->row();
    }

    public function selectDistinct($table,$column,$whr){
        $this->db->select("DISTINCT(".$column.") as name");
        $this->db->from($table);
        if($whr){
            $this->db->where($whr);
        }
        $query = $this->db->get();
        return $query->result();
    }

    public function deleteRow($table,$id){
        $this->db->where('id',$id);
        $this->db->delete($table);
    }

    public function deleteWhr($table,$whr){
        $this->db->where($whr);
        $this->db->delete($table);
    }

    public function fetchRowInfo($table,$id){
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('id',$id);
        $query = $this->db->get();
        return $query->row();
    }

    public function updateRecord($data,$table,$id){
        $this->db->where('id',$id);
        $this->db->update($table,$data);
    }

    //Update Status
    public function updateStatus($status,$id){
        $this->db->where('id',$id);
        $this->db->update('dp_users',array('status'=>$status));  

    }

    public function updateTourStatus($status,$id){
        $this->db->where('id',$id);
        $this->db->update('dp_tour',array('status'=>$status));  

    }

    public function updateRouteStatus($status,$id){
        $this->db->where('id',$id);
        $this->db->update('dp_route',array('status'=>$status));  

    }

    public function updateRouteDaysStatus($status,$id){
        $this->db->where('route_id',$id);
        $this->db->update('dp_route_days',array('status'=>$status));  

    }

    public function updateFlightStatus($status,$id){
        $this->db->where('id',$id);
        $this->db->update('dp_flight',array('status'=>$status));  

    }

    public function updateClientStatus($status,$id){
        $this->db->where('id',$id);
        $this->db->update('dp_testimonial',array('status'=>$status));  

    }

    public function getUsersList(){
        $this->db->select('id,full_name,email');
        $this->db->from('dp_users');
        $query = $this->db->get();
        return $query->result();      
    }

    public function insertData($table,$data){
        $this->db->insert($table,$data);
        return $this->db->insert_id();
    }

    public function insertRecord($table,$data){
        $this->db->insert($table,$data);
        return $this->db->insert_id();
    }

    public function uploadFile($location,$files){
        $path = $files['file']['name'];
        $ext = pathinfo($path, PATHINFO_EXTENSION);
        if($ext=='')
            $ext = 'png';
        $imgname = time() . rand() . '.' . $ext;
        $uploadfile = $location . $imgname;
        if ($files["file"]["name"]) {
            if (move_uploaded_file($files["file"]["tmp_name"],$uploadfile)) {
                return array('status' => true, 'org_image_name' => $path, 'name' => $imgname);
            }
        }
        return array('status' => false);
    }

    public function unlinkFiles($dirs,$file){
        foreach ($dirs as $key => $value){
            if(file_exists($value.$file)){
                unlink($value.$file);
            }
        }
    }

    public function getAllRoutes($whr){
        $this->db->select('dp_route.*,dp_flight.flight_number');
        $this->db->from('dp_route');
        $this->db->join('dp_flight','dp_route.flight_id=dp_flight.id','left');
        if($whr){
            $this->db->where($whr);
        }
        $query = $this->db->get();
        return $query->result();
    }

    public function getUpcomingBooking($whr){
        $this->db->select('dp_booking.*,dp_fly_details.user_id,dp_fly_details.route_id,dp_fly_details.route_days_id,dp_fly_details.flight_no,dp_fly_details.source,dp_fly_details.destination,dp_fly_details.take_of_time,dp_fly_details.landing_time,dp_fly_details.no_of_adult,dp_fly_details.no_of_child,dp_fly_details.booking_price');
        $this->db->from('dp_booking');
        $this->db->join('dp_fly_details','dp_fly_details.booking_id=dp_booking.id','left');
        $this->db->where("dp_booking.journey_date >",date("d-m-y"));
        if($whr){
            $this->db->where($whr);
        }
        $query = $this->db->get();
        return $query->result();
    }

    public function getPastBooking($whr){
        $this->db->select('dp_booking.*,dp_fly_details.user_id,dp_fly_details.route_id,dp_fly_details.route_days_id,dp_fly_details.flight_no,dp_fly_details.source,dp_fly_details.destination,dp_fly_details.take_of_time,dp_fly_details.landing_time,dp_fly_details.no_of_adult,dp_fly_details.no_of_child,dp_fly_details.booking_price');
        $this->db->from('dp_booking');
        $this->db->join('dp_fly_details','dp_fly_details.booking_id=dp_booking.id','left');
        $this->db->where("dp_booking.journey_date <",date("d-m-y"));
        if($whr){
            $this->db->where($whr);
        }
        $query = $this->db->get();
        return $query->result();
    }

    public function getBookingDetails($whr){
        $this->db->select('*');
        $this->db->from('dp_booking');
        if($whr){
            $this->db->where($whr);
        }
        $query = $this->db->get();
        $result = $query->result();
        foreach ($result as $row) {
            /* Get passanger details*/
            $this->db->select('*');
            $this->db->from('dp_passanger');
            $this->db->where('booking_id',$row->id);
            $query = $this->db->get();
            $row->passanger = $query->result();

            /*  get Fly Details  */
            $this->db->select('*');
            $this->db->from('dp_fly_details');
            $this->db->where('booking_id',$row->id);
            $query = $this->db->get();
            $row->fly_details = $query->result();
        }
        return $result[0];
    }

    public function edit_testio_data($id){
        $this->db->select('*');
        $this->db->from('dp_testimonial');
        $this->db->where('id',$id);
        $query = $this->db->get();
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }

    public function fetch_testimonial_data($id){
        $this->db->select('*');
        $this->db->from('dp_testimonial');
        $this->db->where('id',$id);
        $query = $this->db->get();
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }

    public function delete_testimonial($id){
        $this->db->where('id', $id);
        $this->db->delete('dp_testimonial');
    }
    
    public function deleteQuery($query){
        $this->db->query($query);
    }

    public function query($query){
        $fire = $this->db->query($query);
        return $fire->result();
    }
}

