<div id="content_wrapper">
  <div id="header_wrapper" class="header-sm">
    <div class="container-fluid">
      <div class="row">
        <div class="col-xs-12">
          <header id="header">
            <h1><?php echo $row->page_title; ?></h1>
          </header>
        </div>
      </div>
    </div>
  </div>
  <div id="content" class="container-fluid">
    <div class="content-body">
      <div class="row">
        <div class="col-xs-12 col-sm-12">
          <div class="card p-b-20">
            <header class="card-heading ">
              <ul class="card-actions icons right-top">
                <li>
                </li>
              </ul>
            </header>
           <div class="card-body">
            <?php if($this->session->flashdata('sucessmsg')) : ?>
            <div class="alert alert-success" role="alert">
              <?php echo $this->session->flashdata('sucessmsg');?>
            </div>
            <?php endif; ?>
            <?php if($this->session->flashdata('errormsg')) : ?>
            <div class="alert alert-danger" role="alert">
              <strong>Error!</strong> <?php echo $this->session->flashdata('errormsg');?>
            </div>
            <?php endif; ?>
            <form class="form-horizontal" method="post">
              <input type="hidden" name="id" value="<?php echo $row->id; ?>">
              <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Page Title</label>
                  <div class="col-sm-8">
                     <input type="text" name="page_title" placeholder="Page Title" class="form-control"value="<?php echo $row->page_title; ?>">
                  </div>
              </div>
              <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Description</label>
                  <div class="col-sm-10">       
                     <textarea class="ckeditor" id="page_description" name="page_description"><?php echo $row->page_description; ?></textarea>
                  </div>
              </div>
              <div class="form-group">
                  <div class="col-sm-10 col-sm-offset-2">                
                     <input type="submit" class="btn btn-primary" value="update" >
                  </div>
              </div>
            </form>
          </div>
        </div>
      </div>
     </div>
   </div>
 </div> 
</div>
 <script>  
    // Replace the <textarea id="editor"> with an CKEditor
    // instance, using default configurations.
    editor = CKEDITOR.replace( 'page_description', {
      height: 200,
  width: 800
    });
</script>