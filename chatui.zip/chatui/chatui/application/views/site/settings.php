
<!-- white-box -->
<div class="col-md-12 col-lg-10">
    <div class="chat-bg">
        <div class="light-grey-bg">
            <div class="container">
                <div class="row top-heading ">
                    <div class="m-card-set">
                        <svg class="m-card" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
                            <path d="M31.744 27.332a1 1 0 0 1-.076 1.412c-.11.099-2.732 2.411-6.64 2.411-3.909 0-6.53-2.312-6.64-2.411a1 1 0 0 1 1.333-1.491c.033.03 2.195 1.902 5.306 1.902 3.152 0 5.284-1.88 5.305-1.899a.998.998 0 0 1 1.412.076zM25 48C12.318 48 2 37.682 2 25S12.318 2 25 2s23 10.318 23 23-10.318 23-23 23zm0-48C11.193 0 0 11.193 0 25s11.193 25 25 25 25-11.193 25-25S38.807 0 25 0zm10 38.697a.853.853 0 0 1-.06.268l-7-3.73L27.5 35H16c-.552 0-1-.449-1-1V16c0-.551.448-1 1-1h18c.551 0 1 .449 1 1v22.697zM34 13H16c-1.654 0-3 1.346-3 3v18c0 1.654 1.346 3 3 3h11l7.028 3.746h.001A2 2 0 0 0 35 41c.35 0 .698-.093 1.014-.279.617-.363.986-1.308.986-2.024V16c0-1.654-1.346-3-3-3z"></path>
                        </svg>
                    </div>
                    <div class="col-lg-3 col-md-4">
                        <h1>Messenger</h1>
                    </div>
                    <div class="col-lg-4 col-md-4  pl-4 border-left">
                        <p>Chat and help your customers get things done, fast, with intuitive apps and a personalized Messenger home. </p>
                    </div>
                     <div class="col-lg-4 col-md-2">
                                 <div class="home-online-user-icon">
                                  <a href="javascript:void(0);"><i class="la la-expand"></i></i></a>
                                 <a class="dropdown-toggle" data-toggle="dropdown"><i class="la la-ellipsis-v"></i></a>
                                 <div class="dropdown-menu">
                                    <a class="dropdown-item" href="#">Link 1</a>
                                    <a class="dropdown-item" href="#">Link 2</a>
                                    <a class="dropdown-item" href="#">Link 3</a>     
                                 </div>
                              </div>
                          </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-lg-7 col-xl-7">
                <div class="container">
                    <div class="row pt-4">
                        <div class="col-md-12">
                            <h2><span style="color: #88888b;">Chat Box </span>  Settings</h2>
                        </div>
                    </div>
                    <div class="row pt-4">
                        <div class="col-md-12">
                            <div id="accordion">
                                <div class="card">
                                    <div class="card-header" id="headingOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        <div class="row pt-2 pb-2 ">
                                            <div class="col-md-1">
                                                <i class="la la-size la-laptop"></i>
                                            </div>
                                            <div class="col-md-9">
                                                <h5 class="mb-0"> Say hello in (almost) any language</h5>
                                                <p>Introduce your team in up to 38 languages</p>
                                            </div>
                                            <div class="col-md-2 text-center">
                                                <button class="btn btn-link rotate" >
                                                    <i class="la la-angle-right mobile-hide"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-1">
                                                </div>
                                                <div class="col-md-9">
                                                    <p>Greeting <br> Say hi to your customers when they open the Messenger.</p>
                                                    <form>
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">English</label>
                                                            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Hi">
                                                        </div>
                                                    </form>
                                                    <p>Team intro <br>Introduce your team and say how you can help your customer.</p>
                                                    <form>
                                                        <div class="form-group">
                                                            <label for="exampleInputEmail1">English</label>
                                                            <textarea  class="form-control"  placeholder="Ask us anything, or share your feedback."> </textarea>
                                                            <small  class="form-text text-muted">120 characters remaining </small>
                                                        </div>
                                                    </form>
                                                    <p>Default language <br>Display the Messenger interface in:</p>
                                                    <form>
                                                        <div class="form-row align-items-center">
                                                            <div class="col-auto my-1">
                                                                <label class="mr-sm-2 sr-only" for="inlineFormCustomSelect">Preference</label>
                                                                <select class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                                                                    <option selected>English</option>
                                                                    <option value="1">Hindi</option>
                                                                    <option value="2">Punjabi</option>
                                                                    <option value="3">German</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </form>
                                                    <br>
                                                    <p>Additional languages <br>Display the Messenger in these languages when they match your customers' device settings</p>
                                                    <div class="pt-2">
                                                        <a href="javascript:;" class="add-lang" > <i class="la la-plus"></i> Add language </a>
                                                    </div>
                                                    <div class="pt-4">
                                                        <button type="button" class="btn btn-light btn-close" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="pt-2">
                                    <div class="card ">
                                        <div class="card-header" id="heading2" data-toggle="collapse" data-target="#collapse2" aria-expanded="true" aria-controls="collapse2">
                                            <div class="row pt-2 pb-2 ">
                                                <div class="col-md-1">
                                                    <i class="la la-size la-clock-o"></i>
                                                </div>
                                                <div class="col-md-9">
                                                    <h5 class="mb-0"> Set your availability</h5>
                                                    <p>Set team office hours and reply times</p>
                                                </div>
                                                <div class="col-md-2 text-center">
                                                    <button class="btn btn-link rotate" >
                                                        <i class="la la-angle-right mobile-hide"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="collapse2" class="collapse" aria-labelledby="heading2" data-parent="#accordion">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-1">
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p class="pb-0">Set office hours </p>
                                                        <p> Outside these hours, customers see when you'll be back, relative to their timezone..</p>
                                                        <div class="row pl-0 pr-0">
                                                            <div class="col-md-3 ">
                                                                <form>
                                                                    <div class="form-row align-items-center">
                                                                        <div class="col-auto my-1">
                                                                            <label class="mr-sm-2 sr-only" for="inlineFormCustomSelect2">Preference</label>
                                                                            <select class="custom-select mr-sm-2" id="inlineFormCustomSelect2">
                                                                                <option selected>Weekdays</option>
                                                                                <option value="1">Monday</option>
                                                                                <option value="2">Tuesday</option>
                                                                                <option value="3">Thursday</option>
                                                                                <option value="3">Friday</option>
                                                                                <option value="3">Saturday</option>
                                                                                <option value="3">Sunday</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                            <div class="col-md-3 pl-4 ">
                                                                <form>
                                                                    <div class="form-row align-items-center">
                                                                        <div class="col-auto my-1">
                                                                            <label class="mr-sm-2 sr-only" for="inlineFormCustomSelect3">Preference</label>
                                                                            <select class="custom-select mr-sm-2" id="inlineFormCustomSelect3">
                                                                                <option selected>8:00 <small>am</small></option>
                                                                                <option value="1">9:00 <small>am</small></option>
                                                                                <option value="2">10:00 <small>am</small></option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                            <div class="col-md-3 pl-4">
                                                                <form>
                                                                    <div class="form-row align-items-center">
                                                                        <div class="col-auto my-1">
                                                                            <label class="mr-sm-2 sr-only" for="inlineFormCustomSelect4">Preference</label>
                                                                            <select class="custom-select mr-sm-2" id="inlineFormCustomSelect4">
                                                                                <option selected>9:00 <small>pm</small></option>
                                                                                <option value="1">10:00 <small>pm</small></option>
                                                                                <option value="2">11:00 <small>pm</small></option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                            <div class="col-md-1">
                                                                <div class="trash-icon-set">
                                                                    <i class="la la-trash"></i>
                                                                </div>
                                                            </div>
                                                            <div class="pt-2 pl-3">
                                                                <a href="javascript:;" class="add-lang" > <i class="la la-plus"></i> Add office hours </a>
                                                            </div>
                                                        </div>
                                                        <p class="pt-2 mb-2">Reporting preferences</p>
                                                        <div class="form-check pt-1 pb-3 border-bottom">
                                                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                                                            <label style="color: #222222;font-weight: lighter;" class="form-check-label" for="defaultCheck1">
                                                                Calculate your team’s response metrics within office hours only (recommended).
                                                            </label>
                                                        </div>
                                                        <p class="pt-2 mb-2">Set reply time</p>
                                                        <p class="pt-2 mb-2">During office hours, let your customers know when they can expect a reply.</p>
                                                        <div class="form-check pt-1 ">
                                                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                                                            <label class="form-check-label" for="exampleRadios1">
                                                                Automatic reply time. Currently "The team will reply as soon as they
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2">
                                                            <label class="form-check-label" for="exampleRadios2">
                                                                “The team typically replies in a few minutes.”
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios3" value="option3">
                                                            <label class="form-check-label" for="exampleRadios3">
                                                                “The team typically replies in a few hours.”
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios4" value="option4">
                                                            <label class="form-check-label" for="exampleRadios4">
                                                                “The team typically replies in a day.”
                                                            </label>
                                                        </div>
                                                        <p class="pt-2">Note: Operator will auto reply with your team’s availability during out-of-office hours or long reply times.</p>
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <div class="pt-4">
                                                                    <button type="button" class="btn btn-success ">Save And Set Live</button>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <div class="pt-4">
                                                                    <button type="button" class="btn btn-light btn-close" data-toggle="collapse" data-target="#collapse2" aria-expanded="true" aria-controls="collapse2">Close</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="pt-2">
                                    <div class="card ">
                                        <div class="card-header" id="heading3" data-toggle="collapse" data-target="#collapse3" aria-expanded="true" aria-controls="collapse3">
                                            <div class="row pt-2 pb-2 ">
                                                <div class="col-md-1">
                                                    <i class="la la-size la-at"></i>
                                                </div>
                                                <div class="col-md-9">
                                                    <h5 class="mb-0"> Require an email for new conversations</h5>
                                                    <p>So you can always get back to your website visitors</p>
                                                </div>
                                                <div class="col-md-2 text-center">
                                                    <button class="btn btn-link rotate" >
                                                        <i class="la la-angle-right mobile-hide"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="collapse3" class="collapse" aria-labelledby="heading3" data-parent="#accordion">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-1">
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p class="pt-2 mb-2">Ask your website visitors to leave their email before starting a live chat: </p>
                                                        <div class="form-check pt-1 ">
                                                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios5" value="option5" checked>
                                                            <label class="form-check-label" for="exampleRadios5">
                                                                Only outside of office hours
                                                            </label>
                                                            <p class="radio-two-label pb-0 mb-0">educes conversation volume by around 5% on average</p>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios6" value="option6">
                                                            <label class="form-check-label" for="exampleRadios6">
                                                                Always
                                                            </label>
                                                            <p class="radio-two-label pb-0 mb-0">Reduces conversation volume by around 30% on average</p>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios7" value="option7">
                                                            <label class="form-check-label" for="exampleRadios7">
                                                                Never
                                                            </label>
                                                            <p class="radio-two-label pb-0 mb-0">Will allow website visitors to start a conversation at any time</p>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-5">
                                                                <div class="pt-4">
                                                                    <button type="button" class="btn btn-success ">Save And Set Live</button>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-3">
                                                                <div class="pt-4">
                                                                    <button type="button" class="btn btn-light btn-close" data-toggle="collapse" data-target="#collapse3" aria-expanded="true" aria-controls="collapse3">Close</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="pt-2">
                                    <div class="card ">
                                        <div class="card-header" id="heading4" data-toggle="collapse" data-target="#collapse4" aria-expanded="true" aria-controls="collapse4">
                                            <div class="row pt-2 pb-2 ">
                                                <div class="col-md-1">
                                                    <i class="la la-size la-windows"></i>
                                                </div>
                                                <div class="col-md-9">
                                                    <h5 class="mb-0"> Add Messenger home apps</h5>
                                                    <p>Help your customers before they start a conversation</p>
                                                </div>
                                                <div class="col-md-2 text-center">
                                                    <button class="btn btn-link rotate" >
                                                        <i class="la la-angle-right mobile-hide"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="collapse4" class="collapse" aria-labelledby="heading4" data-parent="#accordion">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-1">
                                                    </div>
                                                    <div class="col-md-9">
                                                       <!--  <div class="row">
                                                            <div class="col-md-2 col-4">
                                                                <div class="pt-4">
                                                                    <button type="button" class="btn btn-light ">Visitors</button>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2 col-4">
                                                                <div class="pt-4">
                                                                    <button type="button" class="btn btn-light ">Users</button>
                                                                </div>
                                                            </div>
                                                        </div> -->
                                                        <p class="pt-4 mb-2">Apps for visitors </p>
                                                        <p class=""> Capture new visitors to your website and convert them to leads or users.  </p>
                                                        <p class="pt-4 mb-2" style="color:#888;">Shown On  <i class="la la-globe"></i> Web </p>
                                                        <div class="faq-inside-box">
                                                            <div class="row" >
                                                                <div class="col-md-11">
                                                                    <div class="box-in-box border-black-top">
                                                                        <form>
                                                                            <div class="form-group">
                                                                                <label for="exampleInputEmail">Find an answer yourself</label>
                                                                                <input type="email" class="form-control" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Search For Articles ">
                                                                                <button type="button" class="btn btn-dark btn-in-box"><i class="la la-angle-right" style="font-weight: bold;"></i></button>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-1 trash-icon-set">
                                                                    <i class="la la-bars"></i>
                                                                    <i class="la la-trash" style="color: red;"></i>
                                                                </div>
                                                            </div>
                                                            <div class="pt-5 pl-2">
                                                                <a href="javascript:;" class="add-lang" > <i class="la la-plus"></i> Add an app </a>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-2 col-4">
                                                                <div class="pt-4">
                                                                    <button type="button" class="btn btn-light btn-close" data-toggle="collapse" data-target="#collapse4" aria-expanded="true" aria-controls="collapse4">Close</button>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-5 col-8">
                                                                <div class="pt-4">
                                                                    <a href="javascript:;">
                                                                        <p style="padding-top: 10px;"><i class="la la-file"></i> Choosing the right app </p>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="pt-2">
                                    <div class="card ">
                                        <div class="card-header" id="heading5" data-toggle="collapse" data-target="#collapse5" aria-expanded="true" aria-controls="collapse5">
                                            <div class="row pt-2 pb-2 ">
                                                <div class="col-md-1">
                                                    <i class="la la-size la-pencil"></i>
                                                </div>
                                                <div class="col-md-9">
                                                    <h5 class="mb-0">Style your Messenger</h5>
                                                    <p>Add your logo, choose colors and wallpapers, and turn sounds off or on</p>
                                                </div>
                                                <div class="col-md-2 text-center">
                                                    <button class="btn btn-link rotate" >
                                                        <i class="la la-angle-right mobile-hide"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="collapse5" class="collapse" aria-labelledby="heading5" data-parent="#accordion">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-1">
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p class="pt-4 mb-2">Apps for visitors </p>
                                                        <form>
                                                            <label class="btn-bs-file btn btn-lg btn-light logo-upload">
                                                                <i class="la la-cloud-upload" style="color:#888;"></i>  Upload a Logo
                                                                <input type="file" />
                                                            </label>
                                                        </form>
                                                        <p class="pt-2 mb-2 ">Background color </p>
                                                        <p class=""> Used behind your team profile and other backgrounds.
                                                        <form>
                                                            <label class="btn-bs-file btn btn-lg btn-light logo-upload">
                                                                Choose Color
                                                                <input type="color"/>
                                                            </label>
                                                        </form>
                                                        <p class="pt-2 mb-2 ">Action color </p>
                                                        <p class="">  Used in buttons, links and more to highlight and emphasize.
                                                            .
                                                        <form>
                                                            <label class="btn-bs-file btn btn-lg btn-light logo-upload">
                                                                Choose Color
                                                                <input type="color"/>
                                                            </label>
                                                        </form>
                                                        <p class="pt-2 mb-2 ">Wallpaper </p>
                                                        <div class="row">
                                                            <div class="col-md-2 col-4">
                                                                <div class="">
                                                                    <img src="assets/images/chat-bg/1.png" class="rounded-chat-bg" />
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2 col-4">
                                                                <div class="">
                                                                    <img src="assets/images/chat-bg/2.png" class="rounded-chat-bg" />
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2 col-4">
                                                                <div class="">
                                                                    <img src="assets/images/chat-bg/3.png" class="rounded-chat-bg" />
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2 m-pd-10px col-4">
                                                                <div class="">
                                                                    <img src="assets/images/chat-bg/4.png" class="rounded-chat-bg" />
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2 m-pd-10px col-4">
                                                                <div class="">
                                                                    <img src="assets/images/chat-bg/5.png" class="rounded-chat-bg" />
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2 m-pd-10px col-4">
                                                                <div class="">
                                                                    <img src="assets/images/chat-bg/6.png" class="rounded-chat-bg" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row pt-3">
                                                            <div class="col-md-2 col-4">
                                                                <div class="">
                                                                    <img src="assets/images/chat-bg/7.png" class="rounded-chat-bg" />
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2 col-4">
                                                                <div class="">
                                                                    <img src="assets/images/chat-bg/8.png" class="rounded-chat-bg" />
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2 col-4">
                                                                <div class="">
                                                                    <img src="assets/images/chat-bg/9.png" class="rounded-chat-bg" />
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2 m-pd-10px col-4">
                                                                <div class="">
                                                                    <img src="assets/images/chat-bg/10.png" class="rounded-chat-bg" />
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2 m-pd-10px col-4">
                                                                <div class="">
                                                                    <img src="assets/images/chat-bg/11.png" class="rounded-chat-bg" />
                                                                </div>
                                                            </div>
                                                            <div class="col-md-2 m-pd-10px col-4">
                                                                <div class="">
                                                                    <img src="assets/images/chat-bg/14.png" class="rounded-chat-bg" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <p class="pt-4 mb-2 ">Intercom link <i class="la la-plus plus-bg " ></i> </p>
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" data-toggle="toggle">
                                                                Display a subtle link to the Intercom website
                                                            </label>
                                                        </div>
                                                        <p class="pt-4 mb-2 ">Intercom link <i class="la la-plus plus-bg " ></i> </p>
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" data-toggle="toggle">
                                                                Play a sound for incoming messages
                                                            </label>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-2">
                                                                <div class="pt-4">
                                                                    <button type="button" class="btn btn-light btn-close" data-toggle="collapse" data-target="#collapse5" aria-expanded="true" aria-controls="collapse5">Close</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="pt-2">
                                    <div class="card ">
                                        <div class="card-header" id="heading6" data-toggle="collapse" data-target="#collapse6" aria-expanded="true" aria-controls="collapse6">
                                            <div class="row pt-2 pb-2 ">
                                                <div class="col-md-1">
                                                    <i class="la la-size la-comments"></i>
                                                </div>
                                                <div class="col-md-9">
                                                    <h5 class="mb-0">Control inbound conversations and the launcher</h5>
                                                    <p>Control who can send you messages and where they see the launcher</p>
                                                </div>
                                                <div class="col-md-2 text-center">
                                                    <button class="btn btn-link rotate" >
                                                        <i class="la la-angle-right mobile-hide"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="collapse6" class="collapse" aria-labelledby="heading6" data-parent="#accordion">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-1">
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p class="pt-2 mb-2 " style="color:#222;"> New conversations button  </p>
                                                        <p class="mb-2 ">Intercom link <i class="la la-plus plus-bg " ></i> </p>
                                                        <div class="checkbox">
                                                            <label>
                                                                <input type="checkbox" data-toggle="toggle">
                                                                Let people start new inbound conversations with you
                                                            </label>
                                                        </div>
                                                        <p class="pt-2 mb-4" style="color:#222;"> When this is turned off, people can only reply to the outbound messages you send. </p>
                                                        <p class="border-bottom"></p>
                                                        <p class="pt-2 mb-2" style="color:#222;"> Launcher visibility  </p>
                                                        <p class="mb-2" style="color:#222;"> Control who sees the standard Messenger launcher on your website. </p>
                                                        <p class="mb-2" style="color:#222;"> Any messages you send will still be delivered. </p>
                                                        <p class="pt-2 mb-2" style="color:#222;"> On the web, show the standard Messenger launcher to:  </p>
                                                        <div class="form-check pt-1 ">
                                                            <input class="form-check-input" type="checkbox" name="exampleRadios" id="exampleRadios10" value="option10" checked>
                                                            <label class="form-check-label" for="exampleRadios10">
                                                                users
                                                            </label>
                                                        </div>
                                                        <div class="form-check pt-1 ">
                                                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios11" value="option11" checked>
                                                            <label class="form-check-label" for="exampleRadios11">
                                                                All users
                                                            </label>
                                                        </div>
                                                        <div class="form-check pt-1 ">
                                                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios12" value="option12" checked>
                                                            <label class="form-check-label" for="exampleRadios11">
                                                                Users who match certain data
                                                            </label>
                                                        </div>
                                                        <div class="form-check pt-4 ">
                                                            <input class="form-check-input" type="checkbox" name="exampleRadios" id="exampleRadios13" value="option13" checked>
                                                            <label class="form-check-label" for="exampleRadios13">
                                                                Visitors
                                                            </label>
                                                        </div>
                                                        <div class="form-check pt-1 ">
                                                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios14" value="option14" checked>
                                                            <label class="form-check-label" for="exampleRadios14">
                                                                All visitors
                                                            </label>
                                                        </div>
                                                        <div class="form-check pt-1 ">
                                                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios15" value="option15" checked>
                                                            <label class="form-check-label" for="exampleRadios15">
                                                                Visitors who match certain data
                                                            </label>
                                                        </div>
                                                        <p class="pt-4 mb-4">This doesn’t affect the outbound messages you send. </p>
                                                        <p class="border-bottom"></p>
                                                        <p class="pt-3 mb-2">Launcher position </p>
                                                        <p class=" mb-2">Move your standard Messenger launcher:</p>
                                                        <form>
                                                            <div class="form-row align-items-center">
                                                                <div class="col-auto my-1">
                                                                    <label class="mr-sm-2 sr-only" for="inlineFormCustomSelect2">Preference</label>
                                                                    <select class="custom-select mr-sm-2" id="inlineFormCustomSelect8">
                                                                        <option selected>Left</option>
                                                                        <option value="1">Right</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </form>
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <form>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Side spacing :
                                                                        </label>
                                                                        <input type="number" class="form-control"  aria-describedby="emailHelp" placeholder="0">
                                                                    </div>
                                                                </form>
                                                            </div>
                                                            <div class="offset-md-1 col-md-4">
                                                                <form>
                                                                    <div class="form-group">
                                                                        <label for="exampleInputEmail1">Bottom spacing::
                                                                        </label>
                                                                        <input type="number" class="form-control"  aria-describedby="emailHelp" placeholder="0">
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                        <p class="pt-1 mb-2" style="color: #888;">This changes the position of your Messenger launcher wherever it appears. </p>
                                                        <div class="row">
                                                            <div class="col-md-2">
                                                                <div class="pt-4">
                                                                    <button type="button" class="btn btn-light btn-close" data-toggle="collapse" data-target="#collapse6" aria-expanded="true" aria-controls="collapse6">Close</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="pt-2">
                                    <div class="card">
                                        <div class="card-header" id="heading8" data-toggle="collapse" data-target="#collapse8" aria-expanded="true" aria-controls="collapse8">
                                            <div class="row pt-2 pb-2 ">
                                                <div class="col-md-1">
                                                    <i class="la la-size la-key"></i>
                                                </div>
                                                <div class="col-md-9">
                                                    <h5 class="mb-0"> Keep your Messenger secure</h5>
                                                    <p>Security, domain settings, and identity verification</p>
                                                </div>
                                                <div class="col-md-2 text-center">
                                                    <button class="btn btn-link rotate" >
                                                        <i class="la la-angle-right mobile-hide"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="collapse8" class="collapse" aria-labelledby="heading8" data-parent="#accordion">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-1">
                                                    </div>
                                                    <div class="col-md-9">
                                                        <p class="mb-0">Whitelist your domains</p>
                                                        <p>The Intercom Messenger will only appear on these domains. </p>
                                                        <form>
                                                            <div class="form-group">
                                                                <textarea  class="form-control"  placeholder="Ask us anything, or share your feedback."> </textarea>
                                                                <small>List your domains, separated by a comma. If you leave this field blank, the Messenger can be added to any domain.  </small>
                                                            </div>
                                                        </form>
                                                        <p class="mb-0">Identity verification </p>
                                                        <p>Identity verification prevents third parties from impersonating your logged-in users and seeing their conversations. We strongly recommend that all Intercom customers enforce identity verification.  </p>
                                                        <div class="accordion" id="accordionExample">
                                                            <div class="card">
                                                                <div class="card-header" id="heading8-1" data-toggle="collapse" data-target="#collapse8-1" aria-expanded="true" aria-controls="collapse8-1">
                                                                    <div class="row pt-2 pb-2 ">
                                                                        <div class="col-md-1">
                                                                            <i class="la la-size la-inside la-television"></i>
                                                                        </div>
                                                                        <div class="col-md-9">
                                                                            <h5 class="mb-0"> Identity verification for web users <span class="off"> off</span></h5>
                                                                            <p style="color:#bf9603;"> <i class="la la-warning"></i> Enforce identity verification for web</p>
                                                                        </div>
                                                                        <div class="col-md-2 text-center">
                                                                            <button class="btn btn-link rotate" >
                                                                                <i class="la la-angle-right mobile-hide"></i>
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="pt-2">
                                                                <div class="card">
                                                                    <div class="card-header" id="heading8-2" data-toggle="collapse" data-target="#collapse8-2" aria-expanded="true" aria-controls="collapse8-2">
                                                                        <div class="row pt-2 pb-2 ">
                                                                            <div class="col-md-1">
                                                                                <i class="la la-size la-inside la-apple"></i>
                                                                            </div>
                                                                            <div class="col-md-9">
                                                                                <h5 class="mb-0"> Identity verification for ios users <span class="off"> off</span></h5>
                                                                                <p>Identity verification is not enforced for iOS
                                                                                </p>
                                                                            </div>
                                                                            <div class="col-md-2 text-center">
                                                                                <button class="btn btn-link rotate" >
                                                                                    <i class="la la-angle-right mobile-hide"></i>
                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="pt-2">
                                                                <div class="card">
                                                                    <div class="card-header" id="heading8-3" data-toggle="collapse" data-target="#collapse8-3" aria-expanded="true" aria-controls="collapse8-3">
                                                                        <div class="row pt-2 pb-2 ">
                                                                            <div class="col-md-1">
                                                                                <i class="la la-size la-inside la-android"></i>
                                                                            </div>
                                                                            <div class="col-md-9">
                                                                                <h5 class="mb-0"> Identity verification for Android users <span class="off"> off</span></h5>
                                                                                <p>Identity verification is not enforced for Android
                                                                                </p>
                                                                            </div>
                                                                            <div class="col-md-2 text-center">
                                                                                <button class="btn btn-link rotate" >
                                                                                    <i class="la la-angle-right mobile-hide"></i>
                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="pt-4">
                                                            <button type="button" class="btn btn-light btn-close" data-toggle="collapse" data-target="#collapse8" aria-expanded="true" aria-controls="collapse8">Close</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class=" col-lg-5 col-xl-4 col-md-10 mr-center-0px" >
                <div>

                    <div class="row pd-t-5rem ">
                        <div class="col-md-12">
                            <div class="article-box">
                                <div class="article-img">
                                    <div class="article-img-gradient">
                                        <div class="container hi-there">
                                            <div class="row pt-3">
                                                <div class="col-md-7 col-7">
                                                    <p><span>Wednesday</span> <span>May 13, 2019</span> <span>15:43:11</span> </p>

                                                </div>

                                                <div class="col-md-5 col-5">
                                                    <p style="text-align: right;"><a href="javascript:;"><i class="la la-facebook-f"></i> </a> <a href="javascript:;"><i class="la la-twitter"></i> </a> <a href="javascript:;"><i class="la la-youtube"></i> </a> <a href="javascript:;" style="padding-left: 5px;"><i class="la la-close"></i> </a></p>

                                                </div>

                                            </div>

                                            <div class="row pt-0 helpdesk">
                                                <div class="col-md-10 col-10">
                                                    <h2>WELCOME <br> TO HELPDESK.</h2>          

                                                </div>

                                                <div class="col-md-2 col-2">

                                                    <img src="assets/images/logo-white.png" />

                                                </div>

                                                <div class="col-md-12">
                                                    <p class="mb-0">Let Us Known How We Can Help You Today.</p>
                                                    <p class="mt-0 pb-3">We Will Be Happy To Answer Your Queries.</p>
                                                </div>

                                            </div>



                                        </div>
                                    </div>
                                </div>
                                <div class="container">
                                    <div class="">


                                        <div class="row min-mt-20">
                                            <div class="col-md-2 col-4">

                                                <div class="user-left-profile">
                                                    <img src="./assets/images/user.jpg" class="user-profile" />
                                                </div>
                                            </div>
                                            <div class="col-md-2 col-4 minus-margin-left-20">

                                                <div class="user-left-profile">
                                                    <img src="./assets/images/profile.png" class="user-profile" />
                                                </div>
                                            </div>
                                            <div class="col-md-2 col-4 minus-margin-left-20">

                                                <div class="user-left-profile">
                                                    <img src="./assets/images/user.jpg" class="user-profile" />
                                                </div>
                                            </div>
                                            <div class="col-md-6 m-text-center">
                                                <div class="btn-black-set">
                                                    <button type="button" class="btn btn-black btn-white light-box-shadow"  > <i class="la la-share-square-o"></i> New Conversation</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="pt-3 pb-3">
                                        <div class="box-in-box light-box-shadow ">
                                            <form>
                                             <label for="exampleInputEmail-2" style="font-size: 14px;">Find an answer yourself</label>
                                            <div class="input-group mb-3">
                                              <input type="text" class="form-control" placeholder="Search For Articles" aria-label="Recipient's username" aria-describedby="basic-addon2">
                                              <div class="input-group-append">
                                               <a style="text-decoration: none;" href="javascript:;"> <span class="input-group-text" style="border: 1px solid #5a5ef5;
                                            border-radius: unset;background-color: #5a5ef5;
                                            color: #fff;" id="basic-addon2">></span></a>
                                              </div>
                                            </div>



                                            </form>
                                        </div>
                                    </div>
                                    <div class="row text-center pb-3 ">
                                        <div class=" col">
                                            <div class="box-in-box news light-box-shadow">
                                                <img src="./assets/images/pc.png" style="max-width: 100%"/>
                                                <h4>Aherfs Content Explorer 2.0 : Rebulit from Scratch ( With New Features)</h4>
                                                <p>Introducing the new and much approved ( Aherfs Content Explorer 2.0 : Rebulit from Scratch ( With New Features) ) </p>


                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
