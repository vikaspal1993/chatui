<div id="content_wrapper">
	<div id="header_wrapper" class="header-sm">
		<div class="container-fluid">
			<div class="row">
				<div class="col-xs-12">
					<header id="header">
						<h1>Dashboard</h1>
					</header>
				</div>
			</div>
		</div>
	</div>
	<style type="text/css">
	.row{
	    padding-left: 25px;
	    padding-right: 25px;
	}
</style>
	<div id="content" class="container-fluid">
		<div class="content-body">
			<div class="card">
			  <header class="card-heading">
      			</header>
				   <div class="row">
					 <div class="col-md-3">
						<!-- <div class="card app_primary_bg">
						   <div class="card-body p-b-0">
								<h3 class="m-0 text-white">Today's Flight</h3>
								<span class="text-white block m-b-20">2<?php //echo count($todayflight_count);?></span>
							</div>
						 <div class="card-footer p-5">
								<ul class="card-actions left-bottom">
									<li>
									  <a href="<?php echo base_url();?>admin/flightList" class="btn btn-default btn-flat text-white">
											View Details
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
					  <div class="col-md-3">
						 <div class="card app_accent_bg">
							<div class="card-body p-b-0">
								<div class="text-left">
									<h3 class="m-0 text-white">Total Flights</h3>
										<span class="text-white block m-b-20"><?php echo count($flight_count);?></span>
								  </div>
							    </div>
							<div class="card-footer p-5">
								<ul class="card-actions left-bottom">
									<li>
										<a href="<?php echo base_url();?>admin/flightList" class="btn btn-default btn-flat text-white">
											View Details
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				 <div class="col-md-3">
						<div class="card app_primary_bg">
							<div class="card-body p-b-0">
								<h3 class="m-0 text-white">Total Passenger</h3>
								 <span class="text-white block m-b-20"><?php echo count($user_count);?></span>
								</div>
						  <div class="card-footer p-5">
					   <ul class="card-actions left-bottom">
						  <li>
							 <a href="<?php echo base_url();?>admin/users" class="btn btn-default btn-flat text-white">
											View Details
										</a>
									</li>
								</ul>
							</div>
						</div>
				  </div>
					 <div class="col-md-3">
						<div class="card app_accent_bg">
							<div class="card-body p-b-0">
								<div class="text-left">
									<h3 class="m-0 text-white">Total Flying City</h3>
									<span class="text-white block m-b-20"><?php echo count($flyingcity_count);?></span>
								</div>
							</div>
						 <div class="card-footer p-5">
									<ul class="card-actions left-bottom">
									<li>
										<a href="<?php echo base_url();?>admin/fly_city" class="btn btn-default btn-flat text-white">
											View Details
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<h4 class="lg-title mb5"><b>Last booking</b></h4>
						<div class="table-responsive">
							<table class="table mb30">
								<thead>
									<tr>
					                    <th>Id</th>
					                    <th>User Id</th>
					                    <th>Name</th>
					                    <th >Source</th>
					                    <th>Destination</th>
					                    <th>No Of Adult</th>
					                    <th>No Of Child</th>
					                    <th>Booking Price</th>
					                   
					                    <th>Date Time</th>
									</tr>
							     </thead>
							      <tbody>
								   <?php $i=0; foreach ($booking as $res) { $i++;?>
                  						<tr>
					                    <td>
					                    <?php echo $res->id;?>
					                    </td>
					                    <td><?php echo $res->user_id;?></td>
					                    <td><?php echo $res->name;?></td>
					                    <td><?php echo $res->source;?></td>
					                    <td><?php echo $res->destination;?></td>
					                   <td><?php echo $res->no_of_adult;?></td>
					                   <td><?php echo $res->no_of_child;?></td>
					                   <td><?php echo $res->booking_price;?></td>
					                    
					                    <td><?php echo date("d M, Y H:i A",strtotime($res->datetime));?></td>
                                           <td>
					                  </tr>
					                <?php }?>
								</tbody>
							</table>
						</div>
					</div>
			  </div>
				<div class="row">
					<div class="col-md-12">
						<h4 class="lg-title mb5"><b>Last user</b></h4>
						<div class="table-responsive">
							<table class="table mb30">
								<thead>
									<tr>
					                    <th data-orderable="false">Image</th>
					                    <th >Full Name</th>
					                    <th >Email</th>
					                    <th>Mobile</th>
					                    <th>Status</th>
					                    <th>Action</th>
									</tr>
							     </thead>
							      <tbody>
								   <?php $i=0; foreach ($user as $res) { $i++;?>
                  						<tr>
					                    <td>
					                    <?php if(!empty($res->profile_image)) {?>
					                      <img src="<?php echo base_url();?>assets/img/user/115_115/<?php echo $res->profile_image;?>" alt="" class="img-thumbnail"/>
					                      <?php }else {?>
					                      <img src="<?php echo base_url();?>assets/img/1.jpg" alt="" class="img-thumbnail" />
					                      <?php }?>
					                    </td>
					                    <td>
					                    <?php echo $res->fname;?> <?php echo $res->lname;?>
					                    </td>
					                    <td><?php echo $res->email;?></td>
					                    <td><?php echo $res->mobile;?></td>
					                    <td>
					                      <div class="togglebutton">
					                        <label>
					                          <input onclick="return confirm('Are you sure? You Want To change');" type="checkbox" <?php echo $res->status == 1 ? 'checked' : ''; ?> data-id="<?php echo $res->id;?>" class="toggle-info">
					                        </label>
					                      </div>
					                    </td>
					                  <td>
					                     <a href="<?php echo base_url();?><?php echo $this->uri->segment(1);?>/adduser/<?php echo $res->id;?>" class="edit-product edit-icon"><i class="zmdi zmdi-edit"></i></a>
					                    <a onclick="return confirm('Are you sure? You want to delete');" href="<?php echo base_url();?><?php echo $this->uri->segment(1);?>/deleteUser/<?php echo $res->id;?>" class="delete-product delete-icon"><i class="zmdi zmdi-delete"></i></a>
					                    </td>
					                  </tr>
					                <?php }?>
								</tbody>
							</table>
						</div> -->
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
