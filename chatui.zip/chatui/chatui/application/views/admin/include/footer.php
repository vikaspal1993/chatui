		<!-- <script src="<?php echo base_url();?>assets/admin/js/bootstrap-multiselect.js"></script> -->
<script src="<?php echo base_url();?>assets/admin/js/vendor.bundle.js"></script>
		<script src="<?php echo base_url();?>assets/admin/js/app.bundle.js"></script>

		