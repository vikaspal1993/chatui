<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Site extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model("admin_model");
		$this->load->database();
        $this->load->helper('url');	
	}

	public function index(){
		
		$this->load->view('site/includes/header');
		$this->load->view('site/includes/footer');
   }

   public function profile(){
	$this->load->view('site/includes/header');
	$this->load->view('site/profile');
	$this->load->view('site/includes/footer');
}

public function login(){
	$this->load->view('site/includes/header');
	$this->load->view('site/login');
	$this->load->view('site/includes/footer');
}

 public function chat(){
 	$this->load->view('site/includes/header');
	$this->load->view('site/chat');
	$this->load->view('site/includes/footer');
 }


public function knowledgebase(){
	$this->load->view('site/includes/header');
	$this->load->view('site/knowledgebase');
	$this->load->view('site/includes/footer');
}

public function product_tour(){
	$this->load->view('site/includes/header');
	$this->load->view('site/product_tour');
	$this->load->view('site/includes/footer');
}

public function roadmap(){
	$this->load->view('site/includes/header');
	$this->load->view('site/roadmap');
	$this->load->view('site/includes/footer');
}

public function academic(){
	$this->load->view('site/includes/header');
	$this->load->view('site/academic');
	$this->load->view('site/includes/footer');
}

public function useranalytics(){
	$this->load->view('site/includes/header');
	$this->load->view('site/users');
	$this->load->view('site/includes/footer');
}

public function settings(){
	$this->load->view('site/includes/header');
	$this->load->view('site/settings');
	$this->load->view('site/includes/footer');
}

public function users(){
	$this->load->view('site/includes/header');
	$this->load->view('site/users');
	$this->load->view('site/includes/footer');
}

public function table(){
	$this->load->view('site/includes/header');
	$this->load->view('site/table');
	$this->load->view('site/includes/footer');
}

public function form(){
	$this->load->view('site/includes/header');
	$this->load->view('site/form');
	$this->load->view('site/includes/footer');
}









}