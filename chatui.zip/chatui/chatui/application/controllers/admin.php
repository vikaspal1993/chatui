<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		$this->load->model('common_model');
		$this->load->model('admin_model');
		if($this->session->userdata('admin_id') ==''){
			redirect(base_url().'alogin');
		}
	}

	//Dashboard
	public function index(){
		$whr = array('status' => 1);
		$this->load->view('admin/include/header');
		$this->load->view('admin/index');	
		$this->load->view('admin/include/footer');	
	}
	
	public function profile(){
		$post = $this->input->post();
		if(!empty($post)){
			$this->admin_model->updateRecord($post,"dp_admin");	
			$this->session->set_flashdata('sucessmsg', "Your Profile has been updated successfully");
			redirect(base_url().'admin/profile');
			
	    }else{ 
		    $whr['id'] = "1";
			$data['row']=$this->admin_model->selectRow('dp_admin',$whr);
			$this->load->view('admin/include/header',$data);
			$this->load->view('admin/profile',$data);	
			$this->load->view('admin/include/footer');	
		}
	}
	

	public function setting(){
		$post = $this->input->post();
		if($post){
			$this->admin_model->updateRecord($post,"dp_site_setting",$post['id']);
			$this->session->set_flashdata('sucessmsg', "Site Setting has been updated successfully");
			redirect(base_url().'admin/setting');
		}else{
			$whr['id'] = 1;
			$data['row']=$this->admin_model->selectRow('dp_site_setting',$whr);
			$this->load->view('admin/include/header');
			$this->load->view('admin/setting',$data);	
			$this->load->view('admin/include/footer');	
		}
	}


	public function cms($page_name){
		$post = $this->input->post();
		if($post){
			$this->admin_model->updateRecord($post,"dp_site_content",$post['id']);
			$this->session->set_flashdata('sucessmsg', "Text has been updated successfully");
			redirect(base_url().'admin/cms/'.$page_name);
		}else{
			$whr['page_name'] = $page_name;
			$data['row']=$this->admin_model->selectRow('dp_site_content',$whr);
			$this->load->view('admin/include/header');
			$this->load->view('admin/page',$data);	
			$this->load->view('admin/include/footer');	
		}
	}

	public function promise(){
		$data['row'] = $this->admin_model->selectRow("dp_site_content",false);
		$this->load->view('admin/include/header',$data);
		$this->load->view('admin/page',$data);
		$this->load->view('admin/include/footer');
	}
	
	
	public function terms(){
		$data['row'] = $this->admin_model->selectRow("dp_site_content",false);
		$this->load->view('admin/include/header',$data);
		$this->load->view('admin/term',$data);
		$this->load->view('admin/include/footer');
	}

	
	/*****************************************
		Terms & Conditions end here
	******************************************/

	public function user($type){
		$whr = array('type'=>$type);
		$data['result'] = $this->admin_model->selectRecord('dp_users',$whr);
		$this->load->view('admin/include/header');
		$this->load->view('admin/player',$data);
	}

	public function deletetype($id){
		$this->admin_model->deleteRow("dp_users",$id);
		redirect(base_url().'admin/deleteUser');
	}	

		// public function player(){
		// 	$data['result'] = $this->admin_model->selectList('dp_users');
		// 	$this->load->view('admin/include/header');
		// 	$this->load->view('admin/player',$data);
		// 	$this->load->view('admin/include/footer');
		// }
	     
	 //     public function viewcoach(){
	 //     	$data['result'] = $this->admin_model->selectList('dp_users');
	 //     	$this->load->view('admin/include/header');
	 //     	$this->load->view('admin/viewcoach',$data);
	 //     	$this->load->view('admin/intdiv(dividend, divisor)clude/footer');
	 //     }
	 //     public function teamowner(){
	 //     	$data['result'] = $this->admin_model->selectList('dp_users');
	 //     	$this->load->view('admin/include/header');
	 //     	$this->load->view('admin/teamowner',$data);
	 //     	$this->load->view('admin/include/footer');
	 //     }

	 //     public function fibaagent(){
	 //     	$data['result'] = $this->admin_model->selectList('dp_users');
	 //     	$this->load->view('admin/include/header');
	 //     	$this->load->view('admin/teamowner',$data);
	 //     	$this->load->view('admin/include/footer');
	 //     }

     public function news(){
     	$data['result'] = $this->admin_model->selectList('dp_news');
     	$this->load->view('admin/include/header');
     	$this->load->view('admin/news',$data);
     	$this->load->view('admin/include/footer');
     }

     public function addNews($id=0){
		$post = $this->input->post();
		if(!empty($post)){
			$this->form_validation->set_rules("news_name", "news_name", "trim|required");
			$this->form_validation->set_rules("description", "description", "trim|required");
			if ($this->form_validation->run() == FALSE){
				$this->session->set_flashdata('error', 'Please Fill All Fields');
				if($id!=0){
					redirect(base_url().'admin/addNews/'.$id);
				}else{
					redirect(base_url().'admin/addNews');
				}
			}else {
				if(isset($_FILES['image']['name']) && $_FILES['image']['name'] != ''){
					$config1['upload_path'] = "./assets/img/news/";
					$config1['allowed_types'] = 'gif|jpg|png|jpeg';
					$config1['max_size'] = '1024000000000';
					$config1['remove_spaces'] = true;
					$config1['overwrite'] = false;
					$config1['encrypt_name'] = true;
					$this->load->library('upload', $config1);
					$this->upload->initialize($config1);			
					if (!$this->upload->do_upload('image')){
						echo $error = $this->upload->display_errors();
						$this->session->set_flashdata('errormsg', $error);
						if($id!=0){
							redirect(base_url().'admin/addNews/'.$id);
						}else{
							redirect(base_url().'admin/addNews');
						}				
					}else{
						$image1 = $this->upload->data();
						if ($image1['file_name']){
							$data1['image'] = $image1['file_name'];
						}		
						$images_name = $data1['image'];
						$config1['source_image'] = $data1['image'];
						$config1['new_image'] = base_url()."assets/img/news/";
						$config1['maintain_ratio'] = FALSE;
						$config1['overwrite'] = false;
						$this->load->library('image_lib', $config1); //load library
						$this->image_lib->clear();
						$this->image_lib->initialize($config1);	
					}
					$images_name= $image1['file_name']; 
				}else{
					$images_name = '1.jpg';
				}
				
				if($id!=0){
					if($images_name!='1.jpg'){
						$post['image'] = $images_name;
					}
					$this->admin_model->updateRecord($post,"dp_news",$post['id']);
					$this->session->set_flashdata('success', 'Successfully Updated');
				}else{
					$post['image'] = $images_name;
					$this->admin_model->insertData("dp_news",$post);
					$this->session->set_flashdata('success', 'Successfully Added');
				}
				redirect(base_url().'admin/news');
			}
		}else{
			$this->load->view('admin/include/header');
			if($id!=0){
				$data['userdata'] = $this->admin_model->selectRecord("dp_news",array('id'=>$id));
				$this->load->view('admin/edit_news',$data);	
			}else{
				$this->load->view('admin/addnewas');
			}
			$this->load->view('admin/include/footer');	
		}
	 }
	public function deleteUser($id){
		$this->admin_model->deleteRow("dp_news",$id);
		redirect(base_url().'admin/news');
	}
     
	public function usercontact(){
		$data['result'] = $this->admin_model->selectList('dp_contact_us');
		$this->load->view('admin/include/header');
		$this->load->view('admin/contactuser',$data);	
		$this->load->view('admin/include/footer');

	}
	
	public function delete_contact_user($id){
		$data = $this->admin_model->deleteRow("dp_contact_us",$id);
		$this->session->set_flashdata('success', 'Successfully Deleted');
		redirect(base_url().'admin/usercontact');

	}

    public function league(){
     	$data['result'] = $this->admin_model->selectList('dp_live');
     	$this->load->view('admin/include/header');
     	$this->load->view('admin/league',$data);
     	$this->load->view('admin/include/footer');
     }

     public function addleague($id=0){
		$post = $this->input->post();
		if(!empty($post)){

			$this->form_validation->set_rules("league_name", "league_name", "trim|required");
			if ($this->form_validation->run() == FALSE){
				$this->session->set_flashdata('error', 'Please Fill All Fields');
				if($id!=0){
					redirect(base_url().'admin/addleague/'.$id);
				}else{
					redirect(base_url().'admin/addleague');
				}
			} 
			else {
				if(isset($_FILES['image']['name']) && $_FILES['image']['name'] != ''){
					$config1['upload_path'] = "./assets/img/live/";
					$config1['allowed_types'] = 'gif|jpg|png|jpeg';
					$config1['max_size'] = '1024000000000';
					$config1['remove_spaces'] = true;
					$config1['overwrite'] = false;
					$config1['encrypt_name'] = true;
					$this->load->library('upload', $config1);
					$this->upload->initialize($config1);			
					if (!$this->upload->do_upload('image')){
						echo $error = $this->upload->display_errors();
						$this->session->set_flashdata('errormsg', $error);
						if($id!=0){
							redirect(base_url().'admin/addleague/'.$id);
						}else{
							redirect(base_url().'admin/addleague');
						}				
					}else{
						$image1 = $this->upload->data();
						if ($image1['file_name']){
							$data1['image'] = $image1['image'];
						}		
						$images_name = $data1['image'];
						$config1['source_image'] = $data1['image'];
						$config1['new_image'] = base_url()."assets/img/live/";
						$config1['maintain_ratio'] = FALSE;
						$config1['overwrite'] = false;
						$this->load->library('image_lib', $config1); //load library
						$this->image_lib->clear();
						$this->image_lib->initialize($config1);	
					}
					$images_name= $image1['file_name']; 
				}else{
					$images_name = '1.jpg';
				}
				
				if($id!=0){
					print_r($data);
				exit();
					if($images_name!='1.jpg'){
						$post['image'] = $images_name;
					}
					$this->admin_model->updateRecord($post,"dp_live",$post['id']);
					$this->session->set_flashdata('success', 'Successfully Updated');
				}else{
					
					$this->admin_model->insertData("dp_live",$post);
					$this->session->set_flashdata('success', 'Successfully Added');
				}
				redirect(base_url().'admin/league');
			}
		}else{
			$this->load->view('admin/include/header');
			if($id!=0){
				$data['userdata'] = $this->admin_model->selectRecord("dp_live",array('id'=>$id));
				
				$this->load->view('admin/editleague',$data);	
			}else{
				$this->load->view('admin/addleague');
			}
			$this->load->view('admin/include/footer');	
		}
	 }

	

	public function deleteleague($id){
		$this->admin_model->deleteRow("dp_live",$id);
		redirect(base_url().'admin/league');
	}

public function membership(){
	$data['result'] = $this->admin_model->selectList('dp_membership');
     	$this->load->view('admin/include/header');
     	$this->load->view('admin/membership',$data);
     	$this->load->view('admin/include/footer');

}



 public function addmembership($id=0){
		$post = $this->input->post();
		if(!empty($post)){
			$this->form_validation->set_rules("planname", "live_name", "trim|required");
			$this->form_validation->set_rules("planprice", "live_name", "trim|required");
			$this->form_validation->set_rules("description", "description", "trim|required");
			if ($this->form_validation->run() == FALSE){
				$this->session->set_flashdata('error', 'Please Fill All Fields');
				if($id!=0){
					redirect(base_url().'admin/addmembership/'.$id);
				}else{
					redirect(base_url().'admin/addmembership');
				}
			}else {
				if(isset($_FILES['image']['name']) && $_FILES['image']['name'] != ''){
					$config1['upload_path'] = "./assets/img/live/";
					$config1['allowed_types'] = 'gif|jpg|png|jpeg';
					$config1['max_size'] = '1024000000000';
					$config1['remove_spaces'] = true;
					$config1['overwrite'] = false;
					$config1['encrypt_name'] = true;
					$this->load->library('upload', $config1);
					$this->upload->initialize($config1);			
					if (!$this->upload->do_upload('image')){
						echo $error = $this->upload->display_errors();
						$this->session->set_flashdata('errormsg', $error);
						if($id!=0){
							redirect(base_url().'admin/addlive/'.$id);
						}else{
							redirect(base_url().'admin/addlive');
						}				
					}else{
						$image1 = $this->upload->data();
						if ($image1['file_name']){
							$data1['image'] = $image1['image'];
						}		
						$images_name = $data1['image'];
						$config1['source_image'] = $data1['image'];
						$config1['new_image'] = base_url()."assets/img/live/";
						$config1['maintain_ratio'] = FALSE;
						$config1['overwrite'] = false;
						$this->load->library('image_lib', $config1); //load library
						$this->image_lib->clear();
						$this->image_lib->initialize($config1);	
					}
					$images_name= $image1['file_name']; 
				}else{
					$images_name = '1.jpg';
				}
				
				if($id!=0){
					if($images_name!='1.jpg'){
						$post['image'] = $images_name;
					}
					$this->admin_model->updateRecord($post,"dp_membership",$post['id']);
					$this->session->set_flashdata('success', 'Successfully Updated');
				}else{
					$post['image'] = $images_name;
					$this->admin_model->insertData("dp_membership",$post);
					$this->session->set_flashdata('success', 'Successfully Added');
				}
				redirect(base_url().'admin/membership');
			}
		}else{
			$this->load->view('admin/include/header');
			if($id!=0){
				$data['userdata'] = $this->admin_model->selectRecord("dp_membership",array('id'=>$id));
				$this->load->view('admin/editmembership',$data);	
			}else{
				$this->load->view('admin/addmembership');
			}
			$this->load->view('admin/include/footer');	
		}
	 }

	

	public function deletemembership($id){
		$this->admin_model->deleteRow("dp_membership",$id);
		redirect(base_url().'admin/membership');
	}




public function logout(){
      	$this->session->sess_destroy();
		redirect(base_url().'alogin');

		print_r('logout');
		die();
		exit();
    }


}

	