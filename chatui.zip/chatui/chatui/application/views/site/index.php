

<style>
    body {
        overflow-x: hidden;
    }
    .stat-box-img {
        max-width: 100%;
        border-radius: 10px;
        background-size: cover;
        margin-top: 15px;
    }
    .stat-box {
        background: linear-gradient(135deg,#2a24eb,#1112b8);
        opacity: 0.8;
        padding: 15px 15px;
        border-radius: 10px;
    }
    .stat-box i {
        color: #fff;
        font-size: 30px;
    }
    .stat-box h2 {
        color: #fff;
        font-size: 15px;
        padding-top: 5px;
    }
    .stat-box p {
        color: #fff;
        font-size: 11px;
    }
    .yellow-bg {
        background: linear-gradient(135deg,#c59513,#dca40f) !important;
    }
    .green-bg {
        background: linear-gradient(135deg,#08b95c,#39c674) !important;
    }
    .pink-bg {
        background: linear-gradient(135deg,#b90887,#bb3997) !important;
    }
    .highcharts-credits {
        display: none;
    }
    @media only screen and (max-width: 768px) and (min-width: 300px) {


        .chat-bg .top-heading h1 {

            padding-left: 16px;
        }
        .chat-bg .top-heading .m-card-set {

            padding-left: 28px;
        }
        .my-graph #container{
            margin-left: -15px !important;
        }

    }
    @media only screen and (max-width: 992px) and (min-width: 768px) {
         .padding-1half {
            padding-left: 1.5rem !important;
        }
    }

</style>


<div class="col-md-12 col-lg-10">
    <div class="chat-bg">
        <div class="w-100">
            <div class="light-grey-bg">
                <div class="container">
                    <div class="row top-heading">
                        <div class="m-card-set">
                            <svg width="50" height="50" xmlns="http://www.w3.org/2000/svg"><g fill="#286EFA"><path d="M23 16.5h11v2H23zm0 5h11v2H23zm0 5h8v2h-8zm-17 2v4a1 1 0 0 0 1 1h8v-2H8v-3a5 5 0 0 1 10 0v5h2v-5a7 7 0 0 0-3.78-6.21 5 5 0 1 0-6.44 0A7 7 0 0 0 6 28.5zm4-10a3 3 0 1 1 3 3 3 3 0 0 1-3-3z"></path><path d="M39 1.5H1a1 1 0 0 0-1 1v36h2v-28h36v22a4 4 0 0 1-4 4H5v2h34a1 1 0 0 0 1-1v-35a1 1 0 0 0-1-1zm-37 7v-5h36v5z"></path></g></svg>
                        </div>
                        <div class="col-lg-3 col-md-4">
                        <h1>Home</h1>
                    </div>
                    <div class="col-lg-4 col-md-4  pl-4 border-left">
                        <p>Main page of a website which gives detailed information on its owner and provides links to its other parts. Usually it is the first page.</p>
                    </div>
                     <div class="col-lg-4 col-md-2">
                                 <div class="home-online-user-icon">
                                  <a href="javascript:void(0);"><i class="la la-expand"></i></i></a>
                                 <a class="dropdown-toggle" data-toggle="dropdown"><i class="la la-ellipsis-v"></i></a>
                                 <div class="dropdown-menu">
                                    <a class="dropdown-item" href="#">Link 1</a>
                                    <a class="dropdown-item" href="#">Link 2</a>
                                    <a class="dropdown-item" href="#">Link 3</a>     
                                 </div>
                              </div>
                          </div>
                    </div>
                </div>
            </div>
            <div class=" px-4">

                <div class="row pt-4">
                    <div class="col-lg-2 col-md-6 col-12">
                        <div class="stat-box-img" style=" background: url('./assets/images/chat-bg/13.png');">


                            <div class="stat-box">
                                <i class="la la-user"></i>

                                <h2>User Accounts</h2>
                                <p>1000+ User accounts</p>
                            </div>

                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6 col-12">
                        <div class="stat-box-img" style=" background: url('./assets/images/chat-bg/17.png');">


                            <div class="stat-box yellow-bg">
                                <i class="la la-group"></i>

                                <h2>Team Members</h2>
                                <p>100+ Team Members</p>
                            </div>

                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6 col-12">
                        <div class="stat-box-img" style=" background: url('./assets/images/chat-bg/11.png');">


                            <div class="stat-box green-bg">
                                <i class="la la-calendar-check-o"></i>

                                <h2>Daily Users </h2>
                                <p>80% Users Use Daily</p>
                            </div>

                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6 col-12">
                        <div class="stat-box-img" style=" background: url('./assets/images/chat-bg/10.png');">


                            <div class="stat-box pink-bg">
                                <i class="la la-smile-o"></i>

                                <h2>Happy Clients </h2>
                                <p>100% Clients Happy</p>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 col-12">
                        <div class="stat-box-img" style=" background: url('./assets/images/chat-bg/1.png');">


                            <div class="stat-box ">
                                <i class="la la-comment"></i>

                                <h2>Feedback </h2>
                                <p>We Working On It</p>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 col-12">
                        <div class="stat-box-img" style=" background: url('./assets/images/chat-bg/2.png');">


                            <div class="stat-box yellow-bg">
                                <i class="la la-bar-chart"></i>

                                <h2>Growth </h2>
                                <p>We Growth Very Fast</p>
                            </div>

                        </div>
                    </div>


                </div>



                <div class="row pt-5">
                    <div class="col-lg-12 my-graph border">

                        <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
                        <script src="https://code.highcharts.com/highcharts.js"></script>
                        <script src="https://code.highcharts.com/modules/exporting.js"></script>
                        <script src="https://code.highcharts.com/modules/export-data.js"></script>
                        <script>$.getJSON(
                                'https://cdn.jsdelivr.net/gh/highcharts/highcharts@v7.0.0/samples/data/usdeur.json',
                                function (data) {

                                    Highcharts.chart('container', {
                                        chart: {
                                            zoomType: 'x'
                                        },
                                        title: {
                                            text: 'USD to EUR exchange rate over time'
                                        },
                                        subtitle: {
                                            text: document.ontouchstart === undefined ?
                                                'Click and drag in the plot area to zoom in' : 'Pinch the chart to zoom in'
                                        },
                                        xAxis: {
                                            type: 'datetime'
                                        },
                                        yAxis: {
                                            title: {
                                                text: 'Exchange rate'
                                            }
                                        },
                                        legend: {
                                            enabled: false
                                        },
                                        plotOptions: {
                                            area: {
                                                fillColor: {
                                                    linearGradient: {
                                                        x1: 0,
                                                        y1: 0,
                                                        x2: 0,
                                                        y2: 1
                                                    },
                                                    stops: [
                                                        [0, Highcharts.getOptions().colors[0]],
                                                        [1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
                                                    ]
                                                },
                                                marker: {
                                                    radius: 2
                                                },
                                                lineWidth: 1,
                                                states: {
                                                    hover: {
                                                        lineWidth: 1
                                                    }
                                                },
                                                threshold: null
                                            }
                                        },

                                        series: [{
                                            type: 'area',
                                            name: 'USD to EUR',
                                            data: data
                                        }]
                                    });
                                }
                            );</script>

                        <div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>



                    </div>
                </div>


            </div>
        </div>
    </div>




