         <!-- whitebox - start-->
         <div class="col-md-12 col-lg-10">
            <div class="chat-bg">
               <div class="row">
                  <div class="col-lg-3 col-md-4  p-right-0 border-right">
                     <div class="input-group">
                        <div class="input-group-prepend">
                           <span class="input-group-text home-search-icon" id="basic-addon1"><i class="la la-search"></i></span>
                        </div>
                        <input type="text" class="form-control home-search-box" placeholder="Search Messages" aria-label="Username" aria-describedby="basic-addon1">
                     </div>
                     <div class="Opens">
                        <ul class="nav center-tab nav-tabs mr-15" id="myTab" role="tablist">
                           <li class="nav-item">
                              <a class="nav-link custom-tab active" id="Open" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Open(3)</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link custom-home-border custom-tab" id="Assigned" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Assigned(30)</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link custom-tab" id="Unassigned" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Unassigned(20)</a>
                           </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                           <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="Open">
                              <div class="row home-chat-border" style="border-top:unset !important;">
                                 <div class="col-3">
                                    <div class="home-avtar-icon">
                                       <h6>UL</h6>
                                    </div>
                                 </div>
                                 <div class="col-9 p-left-0">
                                    <div class="avtar-description">
                                       <small>2 mins ago </small>
                                       <span>
                                          <a class="dropdown-toggle" data-toggle="dropdown">
                                          <i class="la la-ellipsis-v"></i></a>
                                          <div class="dropdown-menu">
                                             <a class="dropdown-item" href="#">Link 1</a>
                                             <a class="dropdown-item" href="#">Link 2</a>
                                             <a class="dropdown-item" href="#">Link 3</a>     
                                          </div>
                                       </span>
                                       <a href="javascript:void(0);">
                                          <h6>User From Ludhiana</h6>
                                       </a>
                                       <p>How can i get money back? i have purchased plan a week ago.</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="row home-chat-border">
                                 <div class="col-3">
                                    <div class="home-avtar-icon">
                                       <h6 class="avtar-image-1"></h6>
                                    </div>
                                 </div>
                                 <div class="col-9 p-left-0">
                                    <div class="avtar-description">
                                       <small>Online</small><span class="span-class">Open</span>
                                       <a href="javascript:void(0);">
                                          <h6>Arya Stark</h6>
                                       </a>
                                       <p>Got it.Thanks Again.</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="row home-chat-border">
                                 <div class="col-3">
                                    <div class="home-avtar-icon">
                                       <h6 class="bg-green" >JS</h6>
                                    </div>
                                 </div>
                                 <div class="col-9 p-left-0">
                                    <div class="avtar-description">
                                       <small>a week ago</small><span class="span-class">closed</span>
                                       <a href="javascript:void(0);">
                                          <h6>Jhon Snow</h6>
                                       </a>
                                       <p>How can i change my password?</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="row home-chat-border">
                                 <div class="col-3">
                                    <div class="home-avtar-icon">
                                       <h6 class="avtar-image-2" ></h6>
                                    </div>
                                 </div>
                                 <div class="col-9 p-left-0">
                                    <div class="avtar-description">
                                       <small>2 months ago</small><span class="span-class">closed</span>
                                       <a href="javascript:void(0);">
                                          <h6>Emilia Clarke</h6>
                                       </a>
                                       <p>i need iron thrones.</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="row home-chat-border">
                                 <div class="col-3">
                                    <div class="home-avtar-icon">
                                       <h6 class="bg-yellow" >C</h6>
                                    </div>
                                 </div>
                                 <div class="col-9 p-left-0">
                                    <div class="avtar-description">
                                       <small>a week ago</small><span class="span-class">closed</span>
                                       <a href="javascript:void(0);">
                                          <h6>Cersei</h6>
                                       </a>
                                       <p>i am not going to leave red lead,it is the safest place in king's landing</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="row home-chat-border">
                                 <div class="col-3">
                                    <div class="home-avtar-icon">
                                       <h6 class="avtar-image-3" ></h6>
                                    </div>
                                 </div>
                                 <div class="col-9 p-left-0">
                                    <div class="avtar-description">
                                       <small>2 months ago</small><span class="span-class-color span-class">Not Assigned</span>
                                       <a href="javascript:void(0);">
                                          <h6>Sansa Stark</h6>
                                       </a>
                                       <p>Ok, iam waiting.</p>
                                    </div>
                                 </div>
                              </div>
                              <div class="row home-chat-border">
                                 <div class="col-3">
                                    <div class="home-avtar-icon">
                                       <h6 class="avtar-image-4" ></h6>
                                    </div>
                                 </div>
                                 <div class="col-9 p-left-0">
                                    <div class="avtar-description">
                                       <small>3 months ago</small><span class="span-class-color span-class">Not Assigned</span>
                                       <a href="javascript:void(0);">
                                          <h6>John Deo</h6>
                                       </a>
                                       <p>Thanks for your help, i was stuck at it from last month. I appreciate your support.</p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="Assigned">something-text-1...</div>
                           <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="Unassigned">something-text-2...</div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-9 col-md-8 ">
                     <div class="home-chat-box-header">
                        <div class="row">
                           <div class="col-3">
                              <div class="top-chat-header">                 
                                 <a href="javascript:void(0);"><i class="la la-phone"></i></a>  
                                 <a href="javascript:void(0);"><i class="la la-video-camera"></i></a> 
                              </div>
                           </div>
                           <div class="col-4 text-center">
                              <div class="home-online-user">
                                 <h6>Arya Stark</h6>
                                 <small>online</small>
                              </div>
                           </div>
                           <div class="col-5 pr-30">
                              <div class="home-online-user-icon">
                                  <a href="javascript:void(0);"><i class="la la-expand"></i></i></a>
                                 <a href="javascript:void(0);"><i class="la la-check-circle"></i></a>  
                                 <a class="dropdown-toggle" data-toggle="dropdown"><i class="la la-ellipsis-v"></i></a>
                                 <div class="dropdown-menu">
                                    <a class="dropdown-item" href="#">Link 1</a>
                                    <a class="dropdown-item" href="#">Link 2</a>
                                    <a class="dropdown-item" href="#">Link 3</a>     
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-7 col-lg-8 chat-main-birder">
                           <div class="home-chat-main">
                              <div class="chat-text-right">
                                 <p style="margin-left: 66%; margin-top: 20px;">
                                    <span>Hye Mam.How we can i help you?</span>
                                 </p>
                              </div>
                              <div class="chat-text-left">
                                 <div class="chat-image row">
                                    <img src="assets/images/chat-box/chat-3.jpg" alt="images">      
                                    <p class="text-left">
                                       <span>Hye your chat team is superv. Love it.</span>
                                    </p>
                                 </div>
                              </div>
                              <div class="chat-text-right text-right"">
                                 <p style="margin-left: 78%;text-align: left;">
                                    <span>Thanks.&#128522;</span>
                                 </p>
                              </div>
                              <div class="chat-text-right text-right">
                                 <p style="margin-left: 40%;text-align: left;">
                                    <span>We always try to happy our customer. We are glad that you are happy with us.
                                    </span>
                                 </p>
                              </div>
                              <div class="chat-text-left">
                                 <div class="chat-image row">
                                    <img src="assets/images/chat-box/chat-3.jpg" alt="images">      
                                    <p class="text-left">
                                       <span>
                                       Thanks you,for your awsome service.</span>
                                    </p>
                                 </div>
                              </div>
                              <div class="chat-text-right text-right">
                                 <p style="margin-left: 43%;text-align: left;">
                                    <span>
                                    <b>How to Change your Password?</b><br>
                                    For changing your password,go to your profile,the click on change password,it will lead you to a page where you see...
                                    <a href="javascript:void(0);">http://www.website.com/faq#change-password </a>
                                    </span>
                                 </p>
                              </div>
                              <div class="chat-text-left">
                                 <div class="chat-image row">
                                    <img src="assets/images/chat-box/chat-3.jpg" alt="images">      
                                    <p class="text-left">
                                       <span>Got it. Thanks again.</span>
                                    </p>
                                 </div>
                              </div>
                              <div class="chat-input">
                                 <div class="input-group">  
                                    <input type="text" class="form-control" placeholder="Type a message..." aria-label="Username" aria-describedby="basic-addon1">
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-8">
                                    <div class="input-chat-icon">
                                       <div class="row">
                                          <a href="javascript:void(0);"><span><i class="la la-paperclip"></i></span></a>
                                          <a href="javascript:void(0);"><span><i class="la la-image"></i></span></a>
                                          <a href="javascript:void(0);"><span><i class="la la-smile-o"></i></span></a>
                                          <a href="javascript:void(0);"><span><i class="la la-comment-o"></i></span></a>
                                          <a href="javascript:void(0);"><span><i class="la la-credit-card"></i></span></a>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="col-4">
                                    <div class="text-right chat-send-button">
                                       <button type="button" class="btn btn-primary btn-sm"><i class="la la-paper-plane"></i>Send</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-md-5 col-lg-4">
                           <div class="home-chat-profile">
                              <div class="row">
                                 <div class="col-5 p-right-0"><img src="assets/images/chat-box/chat-3.jpg" alt="profile"></div>
                                 <div class="col-7 p-left-0">
                                    <div class="chat-profile-detail">
                                       <h6>Arya Stark</h6>
                                       <p>Last seen: 24 mins ago,<br><i class="la la-map-marker"></i> Mumbai,india</p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="chat-user-info">
                              <div class="row">
                                 <div class="col-6">
                                    <p class="text-left user-info">User <b>Info</b></p>
                                 </div>
                                 <div class="col-6 text-right">
                                    <a class="user-info" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                                    <i class="la la-angle-down"></i></a>
                                 </div>
                              </div>
                              <div class="collapse" id="collapseExample">
                                 <div class="card card-body custom-card-body">
                                    <div class="chat-card-bg">
                                       <div class="row">
                                          <div class="col-9">
                                             <p><b>Name: </b> Arya Stark</p>
                                          </div>
                                          <div class="col-3">
                                             <div class="info-edit">
                                                <a href="javascript:void(0);"> <i class="la la-pencil" style="padding-top: 6px;"></i>
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="chat-card-bg mt-10">
                                       <div class="row">
                                          <div class="col-9">
                                             <p><b>Email: </b> arya@email.com</p>
                                          </div>
                                          <div class="col-3">
                                             <div class="info-edit">
                                                <a href="javascript:void(0);"> <i class="la la-pencil" style="padding-top: 6px;"></i>
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="chat-card-bg mt-10">
                                       <div class="row">
                                          <div class="col-9">
                                             <p><b>Phone: </b> Not Mentioned</p>
                                          </div>
                                          <div class="col-3">
                                             <div class="info-edit">
                                                <a href="javascript:void(0);"> <i class="la la-pencil" style="padding-top: 6px;"></i>
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="chat-card-bg mt-10">
                                       <div class="row">
                                          <div class="col-9">
                                             <p><b>Company: </b> HBO</p>
                                          </div>
                                          <div class="col-3">
                                             <div class="info-edit">
                                                <a href="javascript:void(0);"> <i class="la la-pencil" style="padding-top: 6px;"></i>
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="chat-detail-border">
                              <div class="chat-other-detail">
                                 <div class="row">
                                    <div class="col-6">
                                       <p class="text-left user-info">Other <b>Details</b></p>
                                    </div>
                                    <div class="col-6 text-right">
                                       <a class="user-info" data-toggle="collapse" href="#otherdetail" role="button" aria-expanded="false" aria-controls="otherdetail">
                                       <i class="la la-angle-down"></i></a>
                                    </div>
                                 </div>
                                 <div class="collapse" id="otherdetail">
                                    <div class="card card-body custom-card-body">
                                       <div class="other-description">
                                          <div class="row">
                                             <i class="la la-crosshairs"></i>
                                             <p class="other-description-text"><b>User IP: </b> 172.1.103.14</p>
                                          </div>
                                          <div class="row">
                                             <i class="la la-exclamation-circle"></i>
                                             <p class="other-description-text"><b>User Agent: </b> Mozilla Firefox</p>
                                          </div>
                                          <div class="row">
                                             <i class="la la-map-marker"></i>
                                             <p class="other-description-text">
                                                <b>
                                                User Location: 
                                                </b>
                                                Punjab, India
                                             </p>
                                          </div>
                                          <div class="row">
                                             <i class="la la-chain"></i>
                                             <p class="other-description-text">
                                                <b>
                                                Site Url: 
                                                </b>
                                                https://www.google.com
                                             </p>
                                          </div>
                                          <div class="row">
                                             <i class="la la-clock-o"></i>
                                             <p class="other-description-text">
                                                <b>
                                                Last Reply: 5 
                                                </b>
                                                minutes ago
                                          </div>
                                          <div class="row">
                                             <i class="la la-laptop"></i>
                                             <p class="other-description-text">
                                                <b>
                                                OS: 
                                                </b>
                                                Mac OS
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- whitebox - end-->


