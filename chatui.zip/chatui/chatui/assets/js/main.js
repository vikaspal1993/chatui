$(document).on('click',function(e){
    if ($(e.target).is('.home-menu,.home-menu *')){
        
    }else if ($(e.target).is('.navbar-menu,.navbar-menu *')){
        
    }
    else if($(e.target).is('.right-menu-trigger, .right-menu-trigger *')){
        if($('.home-menu').hasClass('open')){
            $('body').removeClass('has-menu');
            $('.home-menu').removeClass('open');
            $('.right-menu-trigger').removeClass('open');
        }else{
            $('.home-menu').addClass('open');
            $('body').addClass('has-menu');
            $('.right-menu-trigger').addClass('open');
        }
    }else if($(e.target).is('.left-menu-trigger, .left-menu-trigger *')){
        if($('.navbar-menu').hasClass('open')){
            $('body').removeClass('has-menu');
            $('.navbar-menu').removeClass('open');
            $('.left-menu-trigger').removeClass('open');
        }else{
            $('.navbar-menu').addClass('open');
            $('body').addClass('has-menu');
            $('.left-menu-trigger').addClass('open');
        }
    }else{
        $('body').removeClass('has-menu');
        $('.home-menu').removeClass('open');
        $('.navbar-menu').removeClass('open');
        $('.right-menu-trigger').removeClass('open');
        $('.left-menu-trigger').removeClass('open');
    }
});



var defaultData = 'https://demo-live-data.highcharts.com/time-data.csv';
var urlInput = document.getElementById('fetchURL');
var pollingCheckbox = document.getElementById('enablePolling');
var pollingInput = document.getElementById('pollingTime');

function createChart() {
    Highcharts.chart('container', {
        chart: {
            type: 'spline'
        },
        title: {
            text: 'System Metrics'
        },
        data: {
            csvURL: urlInput.value,
            enablePolling: pollingCheckbox.checked === true,
            dataRefreshRate: parseInt(pollingInput.value, 10)
        }
    });

    if (pollingInput.value < 1 || !pollingInput.value) {
        pollingInput.value = 1;
    }
}

urlInput.value = defaultData;

// We recreate instead of using chart update to make sure the loaded CSV
// and such is completely gone.
pollingCheckbox.onchange = urlInput.onchange = pollingInput.onchange = createChart;

// Create the chart
createChart();






