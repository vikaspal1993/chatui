       <div id="content_wrapper">
          <div id="header_wrapper" class="header-sm">
            <div class="container-fluid">
              <div class="row">
                <div class="col-xs-12">
                  <header id="header">
                    <h1>Edit News</h1>
                  </header>
                </div>
              </div>
            </div>
          </div>
          <div id="content" class="container-fluid">
            <div class="content-body">
            <div class="row">
              <div class="col-xs-12 col-sm-12">
                 <?php if($this->session->flashdata('success')) : ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo $this->session->flashdata('success');?>
                    </div>
                    <?php endif; ?>
                    <?php if($this->session->flashdata('errormsg')) : ?>
                    <div class="alert alert-danger" role="alert">
                      <strong>Error!</strong> <?php echo $this->session->flashdata('errormsg');?>
                    </div>
                    <?php endif; ?>
                <div class="card p-b-20">
                  <header class="card-heading ">
                    <ul class="card-actions icons right-top">
                      <li>
                      </li>
                    </ul>
                  </header>
                  <div class="card-body">
                    <form class="form-horizontal" method="post" enctype="multipart/form-data">
                      <input type="hidden" name="id" value="<?php echo $userdata[0]->id; ?>">
                      <div class="form-group is-empty">
                        <label for="name" class="col-md-2 control-label">Title</label>
                        <div class="col-md-10">
                          <input type="text" class="form-control" name="news_name" placeholder="news Title" id="title" value="<?php echo $userdata[0]->title;?>"/>
                        </div>
                      </div>
                      <div class="form-group">
                          <label for="inputEmail3" class="col-sm-2 control-label">Description</label>
                          <div class="col-sm-10">       
                             <textarea class="ckeditor" id="description" placeholder="tour Description" name="description"><?php echo $userdata[0]->description;?></textarea>
                          </div>
                      </div>
                      <div class="form-group is-empty">
                        <label for="name" class="col-md-2 control-label">Image</label>
                        <div class="col-md-4">
                            <img src="<?php echo base_url();?>assets/img/news/<?php echo $userdata[0]->image?>">
                        </div>
                        <div class="col-md-4 col-md-offset-2" style="clear: both;">
                           <input type="file" name="image" style="opacity: 1;position: relative;font-size: 12px;">
                        </div>
                        </div>
                      </div> 
                      <div class="form-group is-empty">
                        <div class="col-sm-10 col-sm-offset-2">
                          <input type="submit" class="btn btn-info" value="Update">
                          <a class="btn btn-default" href="<?php echo base_url();?>admin/news" value="Back" >BACK</a>
                           </div>
                         </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>