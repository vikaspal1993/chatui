<div id="content_wrapper">
  <div id="header_wrapper" class="header-sm">
    <div class="container-fluid">
      <div class="row">
        <div class="col-xs-12">
          <header id="header">
            <h1>Profile</h1>
          </header>
        </div>
      </div>
    </div>
  </div>
  <div id="content" class="container-fluid">
    <div class="content-body">
      <div class="row">
        <div class="col-xs-12 col-sm-12">
          <div class="card p-b-20">
            <header class="card-heading ">
              <ul class="card-actions icons right-top">
                <li>
                </li>
              </ul>
            </header>
            <div class="card-body">
            <?php if($this->session->flashdata('success')) : ?>
              <div class="alert alert-success" role="alert">
              <?php echo $this->session->flashdata('success');?>
              </div>
            <?php endif; ?>
            <?php if($this->session->flashdata('errormsg')) : ?>
              <div class="alert alert-danger" role="alert">
                <strong>Error!</strong> <?php echo $this->session->flashdata('errormsg');?>
              </div>
            <?php endif; ?>
              <form class="form-horizontal" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id" value="<?php echo $userdata[0]->id; ?>">
              
                <div class="form-group is-empty">
                  <label for="name" class="col-md-2 control-label">First Name</label>
                  <div class="col-md-10">
                    <input type="text" class="form-control" name="fname" id="fname" value="<?php echo $userdata[0]->fname;?>"/>
                  </div>
                </div>
                <div class="form-group is-empty">
                  <label for="name" class="col-md-2 control-label">Last Name</label>
                  <div class="col-md-10">
                    <input type="text" class="form-control" name="lname" id="lname" value="<?php echo $userdata[0]->lname;?>"/>
                  </div>
                </div>
                <div class="form-group is-empty">
                  <label for="inputEmail" class="col-md-2 control-label">Email</label>
                  <div class="col-md-10">
                    <input type="text" class="form-control" name="email" id="email" value="<?php echo $userdata[0]->email;?>"/>
                  </div>
                </div>
                 <div class="form-group is-empty">
                  <label for="inputEmail" class="col-md-2 control-label">Mobile Number</label>
                  <div class="col-md-10">
                    <input type="text" class="form-control" name="Mobile" id="mobile" value="<?php echo $userdata[0]->mobile;?>"/>
                  </div>
                </div>
                  <!-- <label for="name" class="col-md-2 control-label">User Image</label>
                  <div class="col-md-4">
                     <input type="file" name="profile_image" style="opacity: 1;position: relative;font-size: 12px;">
                  </div> -->
                  <label for="name" class="col-md-2 control-label">User Image</label>
                  <div class="col-md-4">
                    <img src="<?php echo base_url();?>assets/img/user/<?php echo $userdata[0]->profile_image?>">
                  </div>
                  <div class="col-md-4 col-md-offset-2" style="clear: both;">
                     <input type="file" name="profile_image" style="opacity: 1;position: relative;font-size: 12px;">
                  </div>
                </div>                       
                <div class="form-group is-empty">
                  <div class="col-sm-10 col-sm-offset-2">
                    <input type="submit" class="btn btn-info" value="Update">
                    <a class="btn btn-default" href="<?php echo base_url();?>admin/users" value="Back" >BACK</a>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>