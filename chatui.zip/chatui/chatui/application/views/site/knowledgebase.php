
<!-- whitebox - start-->
<div class="col-md-12 col-lg-10">
    <div class="chat-bg">
         <div class="light-grey-bg">
                        <div class="container">
                            <div class="row top-heading ">
                                <div class="m-card-set">
                                    <svg class="m-card" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M31.744 27.332a1 1 0 0 1-.076 1.412c-.11.099-2.732 2.411-6.64 2.411-3.909 0-6.53-2.312-6.64-2.411a1 1 0 0 1 1.333-1.491c.033.03 2.195 1.902 5.306 1.902 3.152 0 5.284-1.88 5.305-1.899a.998.998 0 0 1 1.412.076zM25 48C12.318 48 2 37.682 2 25S12.318 2 25 2s23 10.318 23 23-10.318 23-23 23zm0-48C11.193 0 0 11.193 0 25s11.193 25 25 25 25-11.193 25-25S38.807 0 25 0zm10 38.697a.853.853 0 0 1-.06.268l-7-3.73L27.5 35H16c-.552 0-1-.449-1-1V16c0-.551.448-1 1-1h18c.551 0 1 .449 1 1v22.697zM34 13H16c-1.654 0-3 1.346-3 3v18c0 1.654 1.346 3 3 3h11l7.028 3.746h.001A2 2 0 0 0 35 41c.35 0 .698-.093 1.014-.279.617-.363.986-1.308.986-2.024V16c0-1.654-1.346-3-3-3z"></path>
                                    </svg>
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <h1>Knowledgebase</h1>
                                </div>
                                <div class="col-lg-4 col-md-4  pl-4 border-left">
                                    <p> The data in your knowledge base can be from anywhere, but usually comes from several contributors.</p>
                                </div>
                                <div class="col-lg-3 col-md-2">
                                    <div class="home-online-user-icon">
                                  <a href="javascript:void(0);"><i class="la la-expand"></i></i></a>
                                 <a class="dropdown-toggle" data-toggle="dropdown"><i class="la la-ellipsis-v"></i></a>
                                 <div class="dropdown-menu">
                                    <a class="dropdown-item" href="#">Link 1</a>
                                    <a class="dropdown-item" href="#">Link 2</a>
                                    <a class="dropdown-item" href="#">Link 3</a>     
                                 </div>
                              </div>
                          </div>
                            </div>
                        </div>
                    </div>

<div class="row">
<div class="col-md-8">
<div class="user-profile-table">            
            <div class="user-table-main">

                <div class="table-head">
                    <table class="table border table-responsive table-striped">
                        <thead>
                        <tr class="head-row">
                            <th>Name</th>
                            <th>Email</th>
                            <th>Date/Time</th>
                            <th>IP Address</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr class="tabel-body-row">
                            <td>Mark</td>
                            <td>Mark@email.com</td>
                            <td>1900-01-01 12:15:04.123 </td>
                            <td>106.192.137.21</td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit "></i> </span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i></span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Mark</td>
                            <td>Mark@email.com</td>
                            <td>1900-01-01 12:15:04.123 </td>
                            <td>106.192.137.21</td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit "></i> </span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i>  </span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Mark</td>
                            <td>Mark@email.com</td>
                            <td>1900-01-01 12:15:04.123 </td>
                            <td>106.192.137.21</td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit "></i> </span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i>  </span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Mark</td>
                            <td>Mark@email.com</td>
                            <td>1900-01-01 12:15:04.123 </td>
                            <td>106.192.137.21</td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit "></i> </span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i>  </span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Mark</td>
                            <td>Mark@email.com</td>
                            <td>1900-01-01 12:15:04.123 </td>
                            <td>106.192.137.21</td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit "></i> </span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i>  </span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Mark</td>
                            <td>Mark@email.com</td>
                            <td>1900-01-01 12:15:04.123 </td>
                            <td>106.192.137.21</td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit "></i> </span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i>  </span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Mark</td>
                            <td>Mark@email.com</td>
                            <td>1900-01-01 12:15:04.123 </td>
                            <td>106.192.137.21</td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit "></i> </span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i>  </span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Mark</td>
                            <td>Mark@email.com</td>
                            <td>1900-01-01 12:15:04.123 </td>
                            <td>106.192.137.21</td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit "></i> </span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i>  </span></a>
                            </td>
                        </tr>
                        <tr class="tabel-body-row">
                            <td>Mark</td>
                            <td>Mark@email.com</td>
                            <td>1900-01-01 12:15:04.123 </td>
                            <td>106.192.137.21</td>
                            <td class="table-action-btn">
                                <span class="badge badge-primary"><a href="javascript:void(0);"><i class="la la-edit "></i> </span></a>
                                <span class="badge badge-danger"><a href="javascript:void(0);"><i class="la la-trash-o"></i>  </span></a>
                            </td>
                        </tr>
                        <tr>

                        </tr>
                        </tbody>

                    </table>
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-end">
                            <li class="page-item disabled">
                                <a class="page-link" href="#" tabindex="-1">Previous</a>
                            </li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>

            </div>
        </div>
</div>
<div class="col-md-4 pt-35">

<div class="knowledege-form">
                            <form>
                                <h2 class="pb-4">Knowledgebase Form</h2>
                                <div class="form-group">
                                    <input class="form-control" name="username" placeholder="Username" required="required" type="text">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="email" placeholder="Email Address" required="required" type="email">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="password" placeholder="Password" required="required" type="text">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" name="confirm_password" placeholder="Confirm Password" required="required" type="password">
                                </div>
                                <div class="form-group">
                                    <label class="checkbox-inline"><input required="required" type="checkbox"> I accept the <a href="#">Terms of Use</a> &amp; <a href="#">Privacy Policy</a></label>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary btn-sm">Get Started</button>
                                </div>
                            </form>

                        </div>

</div>

</div>


        
    </div>
    <!-- whitebox - end-->

