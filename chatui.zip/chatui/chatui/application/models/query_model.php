<?php
class Query_model extends CI_Model{

	public function fetchRowInfo($table,$id){
		$this->db->select('*');
		$this->db->from($table);
		$this->db->where('id',$id);
		$query = $this->db->get();
		return $query->row();
	}

	//select list of data from a table
	public function selectList($table,$limit=false){
		$this->db->select('*');
		$this->db->from($table);
		if($limit){
			$this->db->limit($limit);
		}
		$this->db->order_by('id','DESC');
		$query = $this->db->get();
		return $query->result();
	}

	public function getAllVideos(){
		$this->db->select('*');
		$this->db->from('dp_playlists');	
		$this->db->where('status',1);	
		$query = $this->db->get();
		$playlists = $query->result();
		$final = array();
		foreach ($playlists as $row) {
			$row->videos = $this->selectRecord('dp_post',array('playlists_id'=>$row->id,'status'=>1),4);			
			if(count($row->videos)>0){
				array_push($final, $row);
			}
		}
		return $final;
	}
	
	//select list of data from a table
	public function selectRecord($table,$whr,$limit=false,$orderBy = 'id',$orderType= 'DESC',$groupBy=false){
		$this->db->select('*',false);
		$this->db->from($table);
		if($whr){
			$this->db->where($whr);
		}
		if($orderBy){
			$this->db->order_by($orderBy,$orderType);
		}
		if($groupBy){
			$this->db->group_by($groupBy);
		}
		if($limit){
			$this->db->limit($limit);
		}
		$query = $this->db->get();
		return $query->result();
	}

	// update table
	public function updateRecord($data,$table,$id){
		$this->db->where('id',$id);
		$this->db->update($table,$data);
	}

	public function updateRecordBy($data,$table,$whr){
		$this->db->where($whr);
		$this->db->update($table,$data);
	}

	//delete row
	public function deleteRow($table,$id){
		$this->db->where('id',$id);
		$this->db->delete($table);
	}

	public function insertData($table,$data){
		$this->db->insert($table,$data);
		return $this->db->insert_id();
	}

	

	public function selectColumns($table,$columns,$whr='',$orderBy = '',$orderType= 'asc'){
		$selects = implode(',', $columns);
		$this->db->select($selects);
		$this->db->from($table);
		if($whr){
			$this->db->where($whr);
		}
		if($orderBy){
			$this->db->order_by($orderBy,$orderType);
		}
		$query = $this->db->get();
		return $query->result();
	}

	public function query($query){
		$fire = $this->db->query($query);
		return $fire->result();
	}

	public function queryRow($query){
		$fire = $this->db->query($query);
		return $fire->row();
	}

	public function dishes($whr=false){
		$this->db->select('dp_dishes.*,dp_users.full_name,dp_users.email,dp_users.mobile_no,dp_users.address,dp_users.days,dp_users.image,dp_users.helpline,dp_users.days,dp_users.start_time as start_time,dp_users.end_time');
		$this->db->from('dp_dishes');
		$this->db->join('dp_users','dp_dishes.user_id=dp_users.id','left');
		if($whr){
			$this->db->where($whr);
		}
		$this->db->order_by('id','DESC');
		$query = $this->db->get();
		return $query->result();
	}

	public function getName($id){
		$this->db->select('full_name');
		$this->db->from('dp_users');
		$this->db->where('id',$id);
		$query = $this->db->get();
		$row = $query->row();
		if(isset($row->full_name)){
			return $row->full_name;
		}else{
			return '--';
		}
	}

	public function allChatList(){
		$this->db->select('dp_messaging.*,dp_users.full_name');
		$this->db->from('dp_messaging');
		$this->db->join('dp_users','dp_messaging.send_to=dp_users.id','left');
		$this->db->order_by('id','DESC');
		$query = $this->db->get();
		$result = $query->result();
		foreach ($result as $row) {
			$row->send_by = $this->getName($row->send_by);
		}
		return $result;
	}

	/*public function getChat($send_by,$send_to){
		$this->db->select('dp_messaging.*,dp_users.full_name,dp_users.image');
		$this->db->from('dp_messaging');	
		$this->db->where('send_by',$send_by);
		$this->db->where('send_to',$send_to);
		$this->db->join('dp_users','dp_messaging.send_to=dp_users.id','left');
		$this->db->order_by('id','DESC');
		$query = $this->db->get();
		return $query->result();
	}*/

	public function getLastChat($memberId,$chatWith){
		$query = $this->db->query("SELECT *,DATE_FORMAT(date,'%d %b %H:%i, %Y') as dates FROM (`dp_messaging`) WHERE (`send_to` = '".$memberId."' OR `send_by` = '".$memberId."') AND (`send_by` = '".$chatWith."' OR `send_to` = '".$chatWith."') and status !='".$memberId."' ");
		return $query->result();
	}

	public function getChatInbox($id){
		$this->db->select('*');
		$this->db->from('dp_users');
		$this->db->where('id !=',$id);
		$query = $this->db->get();
		$result = $query->result();
		$final = array();
		foreach ($result as $row) {
			$row->image = ($row->image!='')?$row->image:'1.jpg';
			$row->chat = $this->getLastChat($id,$row->id);
			if(count($row->chat)>1){
				$row->chatdate = strtotime($row->chat[count($row->chat)-1]->date);
				$row->message = $row->chat[count($row->chat)-1]->message;
				array_push($final, $row);
			}else if(count($row->chat)==1){
				$row->chatdate = strtotime($row->chat[0]->date);
				$row->message = $row->chat[0]->message;
				array_push($final, $row);
			}
		}
		return $final;
	}
}

?>