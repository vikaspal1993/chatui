<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['googleplus']['application_name'] = 'East West Airlines';
$config['googleplus']['client_id']        = '98762712687-lcq9gp0k747boc78fnjn0qinncqei18p.apps.googleusercontent.com';
$config['googleplus']['client_secret']    = 'HrO9OdabAxIf71h6se3N1xjf';
$config['googleplus']['redirect_uri']     = 'http://ewairlines.technofox.co.in/gogle';
$config['googleplus']['api_key']          = 'AIzaSyC6G-bY9IQRVKNQQoHLF5g_PpHXykxl5Bc';
$config['googleplus']['scopes']           = array();

