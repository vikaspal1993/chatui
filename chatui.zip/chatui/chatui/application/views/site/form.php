

<!-- white-box -->
            <div class="col-lg-10 col-md-12">
                <div class="chat-bg">
                    <div class="light-grey-bg">
                        <div class="container">
                            <div class="row top-heading ">
                                <div class="m-card-set">
                                    <svg class="m-card" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M31.744 27.332a1 1 0 0 1-.076 1.412c-.11.099-2.732 2.411-6.64 2.411-3.909 0-6.53-2.312-6.64-2.411a1 1 0 0 1 1.333-1.491c.033.03 2.195 1.902 5.306 1.902 3.152 0 5.284-1.88 5.305-1.899a.998.998 0 0 1 1.412.076zM25 48C12.318 48 2 37.682 2 25S12.318 2 25 2s23 10.318 23 23-10.318 23-23 23zm0-48C11.193 0 0 11.193 0 25s11.193 25 25 25 25-11.193 25-25S38.807 0 25 0zm10 38.697a.853.853 0 0 1-.06.268l-7-3.73L27.5 35H16c-.552 0-1-.449-1-1V16c0-.551.448-1 1-1h18c.551 0 1 .449 1 1v22.697zM34 13H16c-1.654 0-3 1.346-3 3v18c0 1.654 1.346 3 3 3h11l7.028 3.746h.001A2 2 0 0 0 35 41c.35 0 .698-.093 1.014-.279.617-.363.986-1.308.986-2.024V16c0-1.654-1.346-3-3-3z"></path>
                                    </svg>
                                </div>
                                <div class="col-lg-3 col-md-4">
                                    <h1>Form Page</h1>
                                </div>
                                <div class="col-lg-4 col-md-4  pl-4 border-left">
                                    <p>

Chat and help your customers get things done, fast, with intuitive apps and a personalized Messenger home.
</p>
                                </div>
                                 <div class="col-lg-4 col-md-2">
                                 <div class="home-online-user-icon">
                                  <a href="javascript:void(0);"><i class="la la-expand"></i></i></a>
                                 <a class="dropdown-toggle" data-toggle="dropdown"><i class="la la-ellipsis-v"></i></a>
                                 <div class="dropdown-menu">
                                    <a class="dropdown-item" href="#">Link 1</a>
                                    <a class="dropdown-item" href="#">Link 2</a>
                                    <a class="dropdown-item" href="#">Link 3</a>     
                                 </div>
                              </div>
                          </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class=" col-lg-6 col-md-12 mx-auto pt-5">
                            <div class="pb-5 form-class">
                            <form>
                                <h2 class="pb-4">Sample Form</h2>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="username" placeholder="Username" required="required">
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" name="email" placeholder="Email Address" required="required">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="password" placeholder="Password" required="required">
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="confirm_password" placeholder="Confirm Password" required="required">
                                </div>
                                <div class="form-group">
                                    <label class="checkbox-inline"><input type="checkbox" required="required"> I accept the <a href="#">Terms of Use</a> &amp; <a href="#">Privacy Policy</a></label>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn my-btn btn-primary btn-sm">Get Started</button>
                                </div>
                            </form>

                        </div>





                        </div>
                    </div>
                </div>
            </div>
        </div>
