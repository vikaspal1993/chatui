<!doctype html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link href="https://fonts.googleapis.com/css?family=Fira+Sans:400,500,600&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/line-awesome.min.css">
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/main.css">
      <link rel="stylesheet" href="<?php echo base_url();?>assets/css/responsive.css?v=1.0">
       <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
       
       <script src="<?php echo base_url();?>assets/js/bootstrap-snnipet.js"></script>
      <title>CHAT</title>
   </head>
   <body>
       <div class="overlay"></div>
      <div id="background-bg">
         <div id="background-bg-img" style="<?php echo base_url();?>background: url('assets/images/header-bg.png')">
            <header>
               <div class="main-menu">
                  <div class="container">
                     <div class="row">
                        <div class="col-md-2 col-12">
                            <a href="javascript:;" class="left-menu-trigger mobile-visisble"><i><i class="la la-indent"></i></i></a>
                             <a href="index.php">   <img src="assets/images/logo-white.png" class="header-logo" alt="Logo"></a>
                           <a  href="javascript:;" class="right-menu-trigger mobile-visisble"><i><i class="la la-dedent"></i></i></a>
                        </div>
                        <div class="col-md-7 col-12">
                           <ul class="navbar-menu">
                              <li class="active"><a href="<?php echo base_url();?>form">Form</a></li>
                              <li><a href="<?php echo base_url();?>table">Tables</a></li>
                              <li><a href="javascript:;">Operator</a></li>
                              <li><a href="javascript:;">Virtuals</a></li>
                              <li><a href="javascript:;">Casino</a></li>
                              <li><a href="javascript:;">Live Casino</a></li>
                              <li><a href="javascript:;">Games</a></li>
                              <li><a href="javascript:;">Poker</a></li>
                              <li><a href="javascript:;">News</a></li>
                           </ul>
                        </div>
                        <div class="col-md-3 col-12">
                           <div class="dropdown user-dropdown">
                              <button class="btn btn-inverse-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              John Doe
                              </button>
                              <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                 <a class="dropdown-item" href="#">Action</a>
                                 <a class="dropdown-item" href="#">Another action</a>
                                 <a class="dropdown-item" href="#">Something else here</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </header>
            <div id="main">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12 col-lg-2">
                        <div class="sidebar-menu">
                           <div class="user-card">
                              <div class="user-img-box">
                                 <div class="user-img" style="background: url('assets/images/profile.png')" alt="Profile"></div>
                              </div>
                              <div class="user-info">
                                 <h2>John Doe</h2>
                                 <p>Sales Support</p>
                              </div>
                              <div class="user-actions">
                                 <ul>
                                    <li>
                                       <a href="<?php echo base_url();?>profile">
                                       <i class="la la-pencil-square"></i>
                                       <span>Edit Profile</span>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="<?php echo base_url();?>login">
                                       <i class="la la-sign-out"></i>
                                       <span>Logout</span>
                                       </a>
                                    </li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- left-side-menu- start -->
      <div class="icon-bg">
      <div class="container">
      <div class="row">
         <div class="col-md-12 col-lg-2">
            <div class="home-menu">
               <div class="row">
                  <div class="col-6">
                     <div class="home-icon-bg">
                         <a href="<?php echo base_url();?>chat">
                        <div class="mb-min-5"><i class="la la-comments"></i></div>
                        <span>Chat</span>
                        </a>
                     </div>
                  </div>
                  <div class="col-6">
                      <a href="index.php">
                         <div class="home-icon-bg">
                             <a href="<?php echo base_url();?>chat">
                                <div class="mb-min-5"><i class="la la-users"></i></div>
                                <span>Support Desk</span>
                            </a>
                         </div>
                     </a>
                  </div>
               </div>
               <div class="row mt-10">
                  <div class="col-6">
                     <div class="home-icon-bg">
                         <a href="<?php echo base_url();?>knowledgebase">
                            <div class="mb-min-5"><i class="la la-book"></i></div>
                            <span>KnowledgeBase</span>
                        </a>
                     </div>
                  </div>
                  <div class="col-6">
                     <div class="home-icon-bg"> 
                         <a href="<?php echo base_url();?>product_tour">
                            <div class="mb-min-5"><i class="la la-binoculars"></i></div>
                            <span>Product Tours</span>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="row mt-10">
                  <div class="col-6">
                     <div class="home-icon-bg">
                         <a href="<?php echo base_url();?>roadmap">
                            <div class="mb-min-5"><i class="la la-road"></i></div>
                            <span>RoadMap</span>
                        </a>
                     </div>
                  </div>
                  <div class="col-6">
                     <div class="home-icon-bg">
                         <a href="<?php echo base_url();?>academic">
                            <div class="mb-min-5"><i class="la la-paste"></i></div>
                            <span>Academies</span>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="row mt-10">
                  <div class="col-6">
                     <div class="home-icon-bg">
                        <a href="<?php echo base_url();?>users">
                            <div class="mb-min-5"><i class="la la-line-chart"></i></div>
                            <span>User Analytics</span>
                        </a>
                     </div>
                  </div>
                  <div class="col-6">
                     <div class="home-icon-bg">
                         <a href="<?php echo base_url();?>settings">
                            <div class="mb-min-5"><i class="la la-cogs"></i></div>
                            <span>Settings</span>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- left-side-menu- end -->
