
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Fira+Sans:400,500,600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/line-awesome.min.css">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/responsive.css?v=1.0">
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
    <title>CHAT</title>
    <style>

        body {
overflow-x: hidden;
            background-color: #fff;
        }
        .stat-box-img {
            max-width: 100%;
            border-radius: 10px;
            background-size: cover;
            margin-top: 15px;
        }
        .stat-box {
            background: linear-gradient(135deg,#2a24eb,#1112b8);
            opacity: 0.8;
            padding: 10px 15px;
            border-radius: 10px;

        }
        .stat-box i {
            color: #fff !important;
            font-size: 30px ;
        }
        .stat-box h2 {
            color: #fff;
            font-size: 15px;
            padding-top: 5px;
        }
        .stat-box p {
            color: #fff !important;
            font-size: 12px !important; ;
        }
        .stat-page ul.timeline {
            list-style-type: none;
            position: relative;
            padding-left: 1.5rem;
        }

        /* Timeline vertical line */
        .stat-page ul.timeline::before {
            content: ' ';
            background: #4d4ae0;
            display: inline-block;
            position: absolute;
            left: 16px;
            width: 4px;
            height: 100%;
            z-index: 400;
            border-radius: 1rem;
        }
        .stat-page li.timeline-item {
            margin: 20px 0;
        }

        /* Timeline item arrow */
        .stat-page  .timeline-arrow {
            border-top: 0.5rem solid transparent;
            border-right: 0.5rem solid #fff;
            border-bottom: 0.5rem solid transparent;
            display: block;
            position: absolute;
            left: 2rem;
        }

        /* Timeline item circle marker */
        .stat-page li.timeline-item::before {
            content: ' ';
            background: #ddd;
            display: inline-block;
            position: absolute;
            border-radius: 50%;
            border: 3px solid #fff;
            left: 11px;
            width: 14px;
            height: 14px;
            z-index: 400;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
        }
        .chat-bg {
            background-color: #fff;
            border-radius: 10px;
             margin-top: 20px;
            margin-bottom: 20px;
        }
        .logo-set {
            height: 80px;
            width: 80px;
        }
        .logo-set img {
            max-width: 100%;
            padding-left: 28px;
        }
        .btn-blue {
            color: #fff;
            background-color: #2a24eb !important;
            border-color:#2a24eb !important;
        }
        .btn-black-set {

            margin-left: -15px;
        }
        .ld-label {
            width:200px;
            display: inline-block;
        }

        .ld-row {
        }

        .ld-url-input {
            width: 500px;
        }

        .ld-time-input {
            width: 40px;
        }
.display-none {
    display:none;
}
.highcharts-credits {
    display: none;
}
        .h5 {
            font-size:18px !important;
            color: #434343 !important;
        }
        .text-small.mt-2.font-weight-light {
            font-size: 13px;
            color: #434343;
        }
        .small.text-gray {
            color: #2a24eb;
        }
        .stat-page ul.timeline::before {

            background: #4e4e4e !important;

        }
        @media only screen and (max-width: 768px) and (min-width: 300px) {

            .pl-0-m {
                padding-left: 0px !important;
            }
            .logo-set img {
                max-width: 60%;
                padding-left: 0px !important;
            }
            .btn-black-set {
                color: #fff !important;
                padding-top: 10px !important;
                text-align: right;
            }
            .stat-box {
                background: linear-gradient(135deg,#2a24eb,#1112b8);
                opacity: 0.8;
                padding: 10px 10px !important;
                border-radius: 10px;
            }

        }
        @media only screen and (max-width: 992px) and (min-width: 768px) {

            .btn-black-set {
                color: #fff !important;
                padding-top: 10px !important;
                text-align: right;
            }


        }
    </style>
</head>
<body>



<script src="./assets/js/bootstrap-snnipet.js"></script>
<div class="container pl-0">
<div class="col-md-12 stat-page">
    <div class="chat-bg">
        <div class="w-100">
            <div class="light-grey-bg" style="background: #fff;">
                <div class="container">
                    <div class="row top-heading">

                      <div class="col-md-4 col-lg-10 col-4">
                         <div class="logo-set">
                             <img src="assets/images/logo.png"/>


                    </div>
                </div>

                        <div class="col-md-8 col-lg-2 col-8">
                            <div class="btn-black-set">
                                <button type="button" class="btn btn-blue light-box-shadow"> <i class="la la-hand-pointer-o"></i> Subscribe To Updates</button>
                            </div>
            </div>
            <div class=" px-4 pl-0-m">

                <div class="row pt-4">
                    <div class="col-lg-3 col-md-6 col-12">
                      <div class="stat-box-img" style=" background: url('./assets/images/chat-bg/13.png');">


                        <div class="stat-box">
                          <i class="la la-user"></i>

                          <h2>Admin</h2>
                            <p>Lorem Ipsum is simply dummy text. Why do we use it?</p>
                    </div>

                </div>
                </div>

                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="stat-box-img" style=" background: url('./assets/images/chat-bg/17.png');">


                            <div class="stat-box ">
                                <i class="la la-shopping-cart"></i>

                                <h2>Checkout</h2>
                                <p>Lorem Ipsum is simply dummy text. Why do we use it?</p>
                            </div>

                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="stat-box-img" style=" background: url('./assets/images/chat-bg/11.png');">


                            <div class="stat-box ">
                                <i class="la la-dashboard"></i>

                                <h2>Dashboard </h2>
                                <p>Lorem Ipsum is simply dummy text. Why do we use it?</p>
                            </div>

                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="stat-box-img" style=" background: url('./assets/images/chat-bg/10.png');">


                            <div class="stat-box ">
                                <i class="la la-archive"></i>

                                <h2>Storefront </h2>
                                <p>Lorem Ipsum is simply dummy text. Why do we use it?</p>
                            </div>

                        </div>
                    </div>


            </div>

                <div class="row pt-3">
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="stat-box-img" style=" background: url('./assets/images/chat-bg/9.png');">


                            <div class="stat-box ">
                                <i class="la la-mobile"></i>

                                <h2>API & Mobile </h2>
                                <p>Lorem Ipsum is simply dummy text. Why do we use it?</p>
                            </div>

                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="stat-box-img" style=" background: url('./assets/images/chat-bg/8.png');">


                            <div class="stat-box ">
                                <i class="la la-headphones"></i>

                                <h2>Support</h2>
                                <p>Lorem Ipsum is simply dummy text. Why do we use it?</p>
                            </div>

                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="stat-box-img" style=" background: url('./assets/images/chat-bg/7.png');">


                            <div class="stat-box ">
                                <i class="la la-cogs"></i>

                                <h2>Third party services  </h2>
                                <p>Lorem Ipsum is simply dummy text. Why do we use it?</p>
                            </div>

                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="stat-box-img" style=" background: url('./assets/images/chat-bg/6.png');">


                            <div class="stat-box ">
                                <i class="la la-tag"></i>

                                <h2> Point of Sale  </h2>
                                <p>Lorem Ipsum is simply dummy text. Why do we use it?</p>
                            </div>

                        </div>
                    </div>


                </div>


                <div class="row pt-5">
                    <div class="col-lg-12 border">

                        <script src="https://code.highcharts.com/highcharts.js"></script>
                        <script src="https://code.highcharts.com/modules/data.js"></script>

                        <div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>

                        <div class="ld-row display-none">
                            <label class="ld-label">
                                Enable Polling
                            </label>
                            <input type="checkbox" checked="checked" id="enablePolling"/>
                        </div>
                        <div class="ld-row display-none">
                            <label class="ld-label">
                                Polling Time (Seconds)
                            </label>
                            <input class="ld-time-input" type="number" value="2" id="pollingTime"/>
                        </div>
                        <div class="ld-row display-none">
                            <label class="ld-label">
                                CSV URL
                            </label>
                            <input class="ld-url-input" type="text" id="fetchURL"/>
                        </div>





                    </div>
                </div>




                <div class="row pt-5">
                    <div class="col-lg-12 mx-auto">

                        <h2 style="color: #2a24eb;">Past Incidents </h2>

                        <!-- Timeline -->
                        <ul class="timeline">
                            <li class="timeline-item bg-white rounded ml-3 p-4 shadow">
                                <div class="timeline-arrow"></div>
                                <h2 class="h5 mb-0">Title of section 1</h2><span class="small text-gray"><i class="fa fa-clock-o mr-1"></i>21 March, 2019</span>
                                <p class="text-small mt-2 font-weight-light">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque scelerisque diam non nisi semper, et elementum lorem ornare. Maecenas placerat facilisis mollis. Duis sagittis ligula in sodales vehicula....</p>
                            </li>
                            <li class="timeline-item bg-white rounded ml-3 p-4 shadow">
                                <div class="timeline-arrow"></div>
                                <h2 class="h5 mb-0">Title of section 2</h2><span class="small text-gray"><i class="fa fa-clock-o mr-1"></i>5 April, 2019</span>
                                <p class="text-small mt-2 font-weight-light">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque scelerisque diam non nisi semper.</p>
                                <p class="text-small mt-2 font-weight-light">Libero expedita explicabo eius fugiat quia aspernatur autem laudantium error architecto recusandae natus sapiente sit nam eaque, consectetur porro molestiae ipsam! Deleniti.</p>
                            </li>
                            <li class="timeline-item bg-white rounded ml-3 p-4 shadow">
                                <div class="timeline-arrow"></div>
                                <h2 class="h5 mb-0">Title of section 3</h2><span class="small text-gray"><i class="fa fa-clock-o mr-1"></i>18 August, 2019</span>
                                <p class="text-small mt-2 font-weight-light">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque scelerisque diam non nisi semper, et elementum lorem ornare. Maecenas placerat facilisis mollis. Duis sagittis ligula in sodales vehicula....</p>
                            </li>
                            <li class="timeline-item bg-white rounded ml-3 p-4 shadow">
                                <div class="timeline-arrow"></div>
                                <h2 class="h5 mb-0">Title of section 4</h2><span class="small text-gray"><i class="fa fa-clock-o mr-1"></i>10 October, 2019</span>
                                <p class="text-small mt-2 font-weight-light">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque scelerisque diam non nisi semper, et elementum lorem ornare. Maecenas placerat facilisis mollis. Duis sagittis ligula in sodales vehicula....</p>
                                <p class="text-small mt-2 font-weight-light">Voluptatibus temporibus esse illum eum aspernatur, fugiat suscipit natus! Eum corporis illum nihil officiis tempore. Excepturi illo natus libero sit doloremque, laborum molestias rerum pariatur quam ipsam necessitatibus incidunt, explicabo.</p>
                            </li>
                        </ul><!-- End -->

                    </div>
                </div>


        </div>
    </div>
</div>
</div>






    <script src="assets/js/jquery-3.2.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
    <script src="assets/js/main.js"></script>

</body>
</html>
