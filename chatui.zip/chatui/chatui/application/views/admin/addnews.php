<div id="content_wrapper">
  <div id="header_wrapper" class="header-sm">
    <div class="container-fluid">
      <div class="row">
        <div class="col-xs-12">
          <header id="header">
            <h1>Add News</h1>
          </header>
        </div>
      </div>
    </div>
  </div>
  <div id="content" class="container-fluid">
    <div class="content-body">
    <div class="row">
      <div class="col-xs-12 col-sm-12">
        <div class="card p-b-20">
          <header class="card-heading ">
            <ul class="card-actions icons right-top">
              <li>
              </li>
            </ul>
          </header>
          <div class="card-body">
            <?php if($this->session->flashdata('success')) : ?>
            <div class="alert alert-success" role="alert">
              <?php echo $this->session->flashdata('success');?>
            </div>
            <?php endif; ?>
            <?php if($this->session->flashdata('errormsg')) : ?>
            <div class="alert alert-danger" role="alert">
              <strong>Error!</strong> Change a few things up and try submitting again...but not.
            </div>
            <?php endif; ?>
            <form class="form-horizontal" method="post" enctype="multipart/form-data">
              
              <div class="form-group is-empty">
                <label for="name" class="col-md-2 control-label">Title</label>
                <div class="col-md-10">
                  <input type="text" class="form-control" name="title_name" placeholder="Title" id="title_name"/>
                </div>
              </div>
              <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Description</label>
                  <div class="col-sm-10">       
                     <textarea class="ckeditor" id="description" name="description"></textarea>
                  </div>
              </div>
            
              <div class="form-group is-empty">
                <label for="name" class="col-md-2 control-label">Image</label>
                <div class="col-md-4">
                   <input type="file" name="image" style="opacity: 1;position: relative;font-size: 12px;">
                </div>
              </div>               
              <div class="form-group is-empty">
                <div class="col-sm-10 col-sm-offset-2">
                  <input type="submit" class="btn btn-info" value="submit">
                  <a class="btn btn-default" href="<?php echo base_url();?>admin/addnewas" value="Back" >BACK</a>

                </div>
              </div>
            </form>
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>s