<?php
class Common_model extends CI_Model{

    // TO INSERT DATA INTO THE TABLE
	public function insertData($table,$data){
        $this->db->insert($table,$data);
        return $this->db->insert_id();
    }
}

?>