<div id="content_wrapper">
  <div id="header_wrapper" class="header-sm">
    <div class="container-fluid">
      <div class="row">
        <div class="col-xs-12">
          <header id="header">
            <h1>Profile</h1>
          </header>
        </div>
      </div>
    </div>
  </div>
  <div id="content" class="container-fluid">
    <div class="content-body">
      <div class="row">
        <div class="col-xs-12 col-sm-12">
          <div class="card p-b-20">
            <header class="card-heading ">
              <ul class="card-actions icons right-top">
                <li>
                </li>
              </ul>
            </header>
            <div class="card-body">
            <?php if($this->session->flashdata('success')) : ?>
              <div class="alert alert-success" role="alert">
              <?php echo $this->session->flashdata('success');?>
              </div>
            <?php endif; ?>
            <?php if($this->session->flashdata('errormsg')) : ?>
              <div class="alert alert-danger" role="alert">
                <strong>Error!</strong> <?php echo $this->session->flashdata('errormsg');?>
              </div>
            <?php endif; ?>

			<form action="<?php echo base_url()."RegisterUser"?>" method="post">
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="name">Name</label>
					<div class="col-sm-5">
					  <input type="text" name="first_name" class="form-control" value="" placeholder="Enter First name" id="fname">
					</div>
				</div>
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="name">Carrer Goal/interst</label>
					<div class="col-sm-5">
					  <input type="text" name="last_name" class="form-control" value="" placeholder="Enter Last name" id="lname">
					</div>
				</div>
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="email">Email</label>
					<div class="col-sm-5">
					  <input type="email" name="email" class="form-control" placeholder="Enter email" id="email">
					</div>
				</div>
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="jersey/position">jersey/position</label>
					<div class="col-sm-5">
					  <input type="text"  name="jersey/position" class="form-control" value="" placeholder="jersey/position">
					</div>
				</div>
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="password">DOB</label>
					<div class="col-sm-5">
					  <input type="text" name="dob" class="form-control" value="" placeholder="dob">
					</div>
				</div>
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="team name">Team Name</label>
					<div class="col-sm-5">
					  <input type="text" name="team name" class="form-control" placeholder="Team name">
					</div>
				</div>

				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="Brand Apparel preference">Brand Apparel preference</label>
					<div class="col-sm-5">
					  <input type="text" name="Brand Apparel preference" class="form-control"  placeholder="Brand Apparel preference">
					</div>
				</div>

				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="Bio">Bio</label>
					<div class="col-sm-5">
					  <input type="text" name="Bio" class="form-control"  placeholder="Bio">
					</div>
				</div>
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="highliht video url">Highlight Video Url</label>
					<div class="col-sm-5">
					  <input type="text" name="Highlight video url" class="form-control"  placeholder="Highlight video url">
					</div>
				</div>
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="State">State</label>
					<div class="col-sm-5">
					  <input type="text" name="State" class="form-control"  placeholder="State">
					</div>
				</div>
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="State">City</label>
					<div class="col-sm-5">
					  <input type="text" name="State" class="form-control"  placeholder="State">
					</div>
				</div>
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right" for="State">Country</label>
					<div class="col-sm-5">
					  <input type="text" name="State" class="form-control"  placeholder="State">
					</div>
				</div>
				
				<div class="form-group custom-bottom-margin">
					<label class="control-label col-sm-4 text-right"></label>
					<div class="col-sm-5">
					  <button class="btn btn-primary" type="submit">Register</button>
					</div>
				</div>
				
				
			</form>
		</div>
	</div>
</div>	