<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Alogin extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('common_model');
		$this->load->model('admin_model');
	}

	public function index(){
		$post = $this->input->post();
		if(!empty($post)){
			$this->form_validation->set_rules("email", "email", "required");
			$this->form_validation->set_rules("password", "password", "required");
			if ($this->form_validation->run() == FALSE){
				$this->session->set_flashdata('error', 'Please fill username and password');
				redirect(base_url().'alogin');
			}else{
					$results = $this->admin_model->selectRecord("dp_admin",array('email'=>$this->input->post('email'),'password'=>$this->input->post('password')));
					if(count($results)>0){
						if($this->input->post('password')==$results[0]->password){
							$newdata = array(
								'type'=> 'admin',
								'admin_id'  	=> $results[0]->id,
								'admin_email' => $results[0]->email,
								'name'  	=> $results[0]->name,
								'logged_in' 	   => TRUE
							);
							$this->session->set_userdata($newdata);
							redirect(base_url().'admin');
						}
					}else {
						$this->session->set_flashdata('error', 'Username and passwod are not valid.');
						redirect(base_url().'alogin');
					}
				}
		}else{
			$this->load->view('admin/login');
		}
	}

	
}

?>