<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email_model extends CI_Model {

    public function htmlMail($input){
        $this->load->library('email');
        $this->email->set_newline("\r\n");    
        $this->email->set_mailtype("html");
        $this->email->from("no-reply@technofox.co.in", "EWAirlines Admin");
        $data = $input['data'];
        $this->email->to($input['to_email']);  // replace it with receiver mail id
        $this->email->subject($input['subject']); // replace it with relevant subject     
        $body = $this->load->view($input['template'],$data,TRUE);
        $this->email->message($body);   
        $this->email->send();
        /*echo $this->email->print_debugger();*/
    }
       
}