<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.1.6 or newer
 *
 * @package		CodeIgniter
 * @author		ExpressionEngine Dev Team
 * @copyright	Copyright (c) 2008 - 2011, EllisLab, Inc.
 * @license		http://codeigniter.com/user_guide/license.html
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * CodeIgniter URL Helpers
 *
 * @package		CodeIgniter
 * @subpackage	Helpers
 * @category	Helpers
 * @author		ExpressionEngine Dev Team
 * @link		http://codeigniter.com/user_guide/helpers/url_helper.html
 */

// ------------------------------------------------------------------------

/**
 * Site URL
 *
 * Create a local URL based on your basepath. Segments can be passed via the
 * first parameter either as a string or an array.
 *
 * @access	public
 * @param	string
 * @return	string
 */
	
	
	//password generater


function getDayName($dates){
	$date = date('D', strtotime($dates));
	switch($date){
		case "Mon":
			return "monday";
			break;
		case "Tue":
			return "tuesday";
			break;
		case "Wed":
			return "wednesday";
			break;
		case "Thu":
			return "thrusday";
			break;
		case "Fri":
			return "friday";
			break;
		case "Sat":
			return "saturday";
			break;
		case "Sun":
			return "sunday";
			break;
	}
}

function saveIpAddress(){
	$CI =& get_instance();
	$data['ip_address'] = $_SERVER['REMOTE_ADDR'];
	
	$exist = $CI->db->select("*")->from("dp_visitors")->where($data)->get()->row();
	if(empty($exist))
	$CI->db->insert("dp_visitors",$data);
}

function getRemoteIp(){
	return $_SERVER['REMOTE_ADDR'];
}

function changeTimeToString($time,$datetime){
    $newtime = '';
    $ts = $time;
    if(!ctype_digit($ts))
      $ts = strtotime($ts);
    
    $diff = strtotime($datetime) - $ts;
    if($diff == 0)
      $newtime =  '0 minute ago';
    elseif($diff > 0)
    {
      $day_diff = floor($diff / 86400);
      if($day_diff == 0){
        if($diff < 60){
            $newtime =  '0 minute ago';
        }else if($diff < 120){
            $newtime =  '1 minute ago';
        }else if($diff < 3600){
            $newtime =  floor($diff / 60) . ' minutes ago';
        }else if($diff < 7200){
            $newtime =  '1 hour ago';
        }else if($diff < 86400){
            $newtime =  floor($diff / 3600) . ' hours ago';
        }
      }else if($day_diff == 1){
          $newtime =  'Yesterday';
      }else if($day_diff < 7){
          $newtime =  $day_diff . ' days ago';
      }else if($day_diff < 31){
          $newtime =  ceil($day_diff / 7) . ' weeks ago';
      }else if($day_diff < 60){
          $newtime =  'last month';
      }
         
    }
    else
    {
      $diff = abs($diff);
      $day_diff = floor($diff / 86400);
      if($day_diff == 0)
      {
        if($diff < 120){
            $newtime =  'in a minute';
        }else if($diff < 3600){
            $newtime =  'in ' . floor($diff / 60) . ' minutes';
        }else if($diff < 7200){
            $newtime =  'in an hour';
        }else if($diff < 86400){
            $newtime =  'in ' . floor($diff / 3600) . ' hours';
        }
      }
      else if($day_diff == 1){
          $newtime =  'Tomorrow';
      }else if($day_diff < 4){
          $newtime =  date('l', $ts);
      }else if($day_diff < 7 + (7 - date('w'))){
          $newtime =  'next week';
      }else if(ceil($day_diff / 7) < 4){
          $newtime =  'in ' . ceil($day_diff / 7) . ' weeks';
      }else if(date('n', $ts) == date('n') + 1){
          $newtime =  'next month';
      }
    }
    return $newtime;
}

function getCountryName($ipAddress){
	$ip = $ipAddress;
	$ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));
	return $ip_data;
}
