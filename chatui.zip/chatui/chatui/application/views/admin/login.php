<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <title>EastWeast Airlines - Admin Panel</title>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700|Poppins:300,400,500,600" rel="stylesheet">
	<link rel="icon" href="<?php echo base_url();?>assets/img/favicon.ico" type="image/x-icon">
  

  <link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/vendor.bundle.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/app.bundle.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/theme-a.css">
  <style>
    body #forget_content{
    overflow: hidden;
    background: #fff;
    -webkit-box-shadow: 0 5px 12px rgba(0,0,0,.2);
    -moz-box-shadow: 0 5px 12px rgba(0,0,0,.2);
    -ms-box-shadow: 0 5px 12px rgba(0,0,0,.2);
    -o-box-shadow: 0 5px 12px rgba(0,0,0,.2);
    box-shadow: 0 5px 12px rgba(0,0,0,.2);
    -webkit-transition: all,.2s,ease-in-out;
    -khtml-transition: all,.2s,ease-in-out;
    -moz-transition: all,.2s,ease-in-out;
    -ms-transition: all,.2s,ease-in-out;
    -o-transition: all,.2s,ease-in-out;
    transition: all,.2s,ease-in-out;
    position: relative;
    width: 375px;
    padding: 0 30px 30px;
}
*, :active, :focus {
    outline: 0;
}
*, :after, :before {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
  </style>
</head>
<body id="auth_wrapper" >
  <div id="login_wrapper">

    <div id="login_content">
			<div class="logo">
				<img src="<?php echo base_url();?>assets/site/images/logo.png" class="logo-img">
			</div>
      <h1 class="login-title">
        Sign In to your account
      </h1>

      <div class="login-body">
        <form action="" method="post">
        <?php if($this->session->flashdata('error')) : ?>
          <div class="alert alert-danger" role="alert">
             <?php echo $this->session->flashdata('error');?>
          </div>
        <?php endif; ?>
          <div class="form-group label-floating is-empty">
            <label class="control-label">email</label>
            <input type="text" class="form-control" name="email">
          </div>
          <div class="form-group label-floating is-empty">
            <label class="control-label">Password</label>
            <input type="password" class="form-control" name="password">
          </div>
          <button type="submit" class="btn btn-info btn-block m-t-20">Sign In</button>
          <a href="javascript:;" onclick="forgetPassword();">Forget Password</a>
        </form>
      </div>
      <div id="register_wrapper">
        <ul class="card-actions icons right-top">
          <li>
            <a href="javascript:void(0)" data-toggle="register">
              <i class="zmdi zmdi-close"></i>
            </a>
          </li>
        </ul>
				<div class="logo">
					<img src="<?php echo base_url();?>assets/site/images/logo.png" alt="logo" class="logo-img">
				</div>
    </div>    
  </div>

  <div id="forget_content" style="display: none;">
      <div class="logo">
        <img src="<?php echo base_url();?>assets/site/images/logo.png" class="logo-img">
      </div>
      <h1 class="login-title">
        Forget Password
      </h1>
      <div class="login-body">
        <form method="post" id="forgetPasswordform" name="forgetPasswordform">
           <div id="forgetmessage"></div>
        <?php if($this->session->flashdata('error')) : ?>
          <div class="alert alert-danger" role="alert">
             <?php echo $this->session->flashdata('error');?>
          </div>
        <?php endif; ?>
          <div class="form-group label-floating is-empty">
            <label class="control-label">email</label>
            <input type="text" class="form-control" name="email">
          </div>
          <button type="button" class="btn btn-info btn-block m-t-20" onclick="doAdminForgetPassword();">Submit</button>
        </form>
      </div>
    </div>
  </div>
<script src="<?php echo base_url();?>assets/admin/js/vendor.bundle.js"></script>
    <script src="<?php echo base_url();?>assets/admin/js/app.bundle.js"></script>
    <script src="<?php echo base_url();?>assets/admin/js/common.js"></script>
</body>
</html>
<script>
  var base_url = "<?php echo base_url();?>";
  function forgetPassword(){
    $("#forget_content").show();
    $("#login_content").hide();
  }

  function doAdminForgetPassword(){
    var $form = $("#forgetPasswordform");
    var data = getFormData($form);
    if(data.email==''){
        $("#forgetmessage").show();
        $("#forgetmessage").html("<font color='red'>Please enter email address</font>");
        setTimeout(function(){$("#forgetmessage").hide();},2500);
        return;
    }else if(validateEmail(data.email)){
        $("#forgetmessage").show();
        $("#forgetmessage").html("<font color='red'>Please enter valid email address</font>");
        setTimeout(function(){$("#forgetmessage").hide();},2500);
        return;
    }else{
        /*$("#jc-forget").show();*/
        $.ajax({        
            type : 'POST',
            url : base_url+'login/forgotPassword',
            headers : {},
            contentType : 'application/json',
            dataType: 'json',
            data: JSON.stringify(data),
            success : function(response) {
                if(response.success){
                    $("#forgetmessage").show();
                    $("#forgetmessage").html("<font color='green'>"+response.message+"</font>");
                    setTimeout(function(){
                        window.location.href=base_url+"alogin";
                    },1500);    
                }else{
                    $("#forgetmessage").show();
                    $("#forgetmessage").html("<font color='red'>"+response.message+"</font>");
                }
            },
            error : function(xhr, status, error) {
                //$("#jc-forget").hide();
                $("#forgetmessage").show();
                $("#forgetmessage").html("<font color='red'>There is an error</font>");
            }
        });
    }
}

function getFormData($form){
    var unindexed_array = $form.serializeArray();
    var indexed_array = {};
    console.log(unindexed_array);
    $.map(unindexed_array, function(n, i){
        indexed_array[n['name']] = n['value'];
    });
    return indexed_array;
}
function validateEmail(email){
    console.log(email);
    var x = email;
    var atpos = x.indexOf("@");
    var dotpos = x.lastIndexOf(".");
    if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {
        return true;
    }else{
        return false;
    }
}
</script>