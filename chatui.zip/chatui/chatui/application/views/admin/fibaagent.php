<div id="content_wrapper">
    <div id="header_wrapper" class="header-sm">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-12">
            <header id="header">
              <h1>Fiba Agent</h1>
              <!-- <a href="<?php echo base_url();?><?php echo $this->uri->segment(1);?>/adduser"><button type="button" class="btn btn-primary btn-fab  animate-fab pull-right" style="margin-top: -9px;height: 50px;"><i class="zmdi zmdi-plus"></i></button></a> -->
            </header>
          </div>
        </div>
      </div>
   </div>
<div id="content" class="container-fluid">
  <div class="content-body">
    <div class="row">
      <div class="col-xs-12">
        <div class="card card-data-tables product-table-wrapper">
          <header class="card-heading">
            <div class="card-search">
              <div id="productsTable_wrapper" class="form-group label-floating is-empty">
                <i class="zmdi zmdi-search search-icon-left"></i>
                <input type="text" class="form-control filter-input" placeholder="Filter Data..." autocomplete="off">
                <a href="" class="close-search" data-card-search="close" data-toggle="tooltip" data-placement="top" title="Close"><i class="zmdi zmdi-close"></i></a>
              </div>
          </div>
            <ul class="card-actions icons right-top">
              <li id="deleteItems" style="display: none;">
                <span class="label label-info pull-left m-t-5 m-r-10 text-white"></span>
                <a href="javascript:;" id="confirmDelete" name="delete" data-toggle="tooltip" data-placement="top" data-original-title="Delete">
                  <i class="zmdi zmdi-delete"></i>
                </a>
             </li>
              <li>
                <a href="javascript:void(0)" data-card-search="open" data-toggle="tooltip" data-placement="top" data-original-title="Filter Data">
                  <i class="zmdi zmdi-filter-list"></i>
                </a>
              </li>
              <li class="dropdown" data-toggle="tooltip" data-placement="top" data-original-title="Show Entries">
                <a href="javascript:void(0)" data-toggle="dropdown">
                  <i class="zmdi zmdi-more-vert"></i>
                </a>
                <div id="dataTablesLength">
                </div>
              </li>
              
            </ul>
          </header>
            <div class="table-responsive">
              <form id="delet-form" method="post">
                <?php if($this->session->flashdata('success')) : ?>
                  <div class="alert alert-success" role="alert">
                    <?php echo $this->session->flashdata('success');?>
                  </div>
                  <?php endif; ?>
                  <?php if($this->session->flashdata('errormsg')) : ?>
                  <div class="alert alert-danger" role="alert">
                    <strong>Error!</strong> <?php echo $this->session->flashdata('errormsg');?>
                  </div>
                <?php endif; ?>
               <input type="hidden" value="Delete" name="">
              <table id="productsTable" class="mdl-data-table product-table m-t-30" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th data-orderable="false" class="col-xs-1">
                      <span class="checkbox">
                        <label>
                          <input type="checkbox" name="submit-button" value="delete" id="checkAll">
                          <span class="checkbox-material"></span>
                        </label>
                      </span>
                    </th>
                    <th >First Name</th>
                    <th >Last Name</th>
                    <th >Email</th>
                    <th>Mobile</th>
                    <th data-orderable="false" style="width:130px;">
                      Action
                    </th>
                  </tr>
              </thead>
                 <tbody>
                  <?php $i=0; foreach ($result as $res) { $i++;?>
                  <tr>
                    <td class="checkbox-cell">
                      <span class="checkbox">
                        <label>
                          <input type="checkbox" name='ids[]' value="<?php echo $res->id;?>" class="userids">
                          <span class="checkbox-material"></span>
                        </label>
                      </span>
                    </td>
                    <td>
                    <?php echo $res->fname;?> 
                    </td>
                    <td><?php echo $res->lname;?></td>
                    <td><?php echo $res->email;?></td>
                    <td><?php echo $res->mobile;?></td>
                    <td>
                      <a onclick="return confirm('Are you sure? You want to delete');" href="<?php echo base_url();?><?php echo $this->uri->segment(1);?>/deleteUser/<?php echo $res->id;?>" class="delete-product delete-icon"><i class="zmdi zmdi-delete"></i></a>
                    </td>
                  </tr>
                   <?php }?>
                </tbody>
              </table>
            </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>